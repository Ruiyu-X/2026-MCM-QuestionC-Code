# plot_gallery_fixed.py
# Robust figure gallery generator (compatible with multiple dataset schema variants)
# Usage:
#   python plot_gallery_fixed.py --data 2026_MCM_Problem_C_Data.csv --results_dir /path/to/results --out_dir mcmC_figure_gallery
#
# This script is a patched/robust version of the original plot_gallery.py:
# - Avoids hard-coded raw column names by auto-detecting schema variants
# - Computes missing derived columns when result bundles use different naming
# - Skips/backs-off gracefully when optional inputs are absent
# python "plot_gallery_fixed.py" --data ".\2026_MCM_Problem_C_Data.csv" --results_dir ".\mcmC_results(modified)" --out_dir ".\mcmC_figure_gallery(fixed)"
import re, argparse
import numpy as np
import pandas as pd
import matplotlib.pyplot as plt
import matplotlib as mpl
from pathlib import Path

parser = argparse.ArgumentParser()
parser.add_argument("--data", type=str, required=True, help="Raw dataset CSV (the big MCM C dataset)")
parser.add_argument("--results_dir", type=str, required=True, help="Directory containing task result CSVs")
parser.add_argument("--out_dir", type=str, required=True, help="Directory to save figures")
args = parser.parse_args()

out_dir = Path(args.out_dir)
out_dir.mkdir(parents=True, exist_ok=True)

def _read_csv(p):
    p = Path(p)
    if not p.exists():
        raise FileNotFoundError(f"Missing file: {p}")
    return pd.read_csv(p)

raw = _read_csv(args.data)
task1 = _read_csv(Path(args.results_dir)/"task1_fan_vote_estimates.csv")
task2d = _read_csv(Path(args.results_dir)/"task2_rule_comparison_deterministic.csv")
task2p = _read_csv(Path(args.results_dir)/"task2_rule_comparison_probabilistic.csv")
task3 = _read_csv(Path(args.results_dir)/"task3_industry_effects.csv")
task4 = _read_csv(Path(args.results_dir)/"task4_fairness_grid.csv")
pareto = _read_csv(Path(args.results_dir)/"task4_pareto_frontier.csv")

mpl.rcParams.update({
    "figure.dpi": 220,
    "savefig.dpi": 300,
    "font.size": 10,
    "axes.titlesize": 11,
    "axes.labelsize": 10,
    "legend.fontsize": 9,
    "axes.spines.top": False,
    "axes.spines.right": False,
    "axes.grid": True,
    "grid.alpha": 0.18,
    "grid.linestyle": "-",
    "axes.facecolor": "#ffffff",
    "figure.facecolor": "#ffffff",
})

palette = {
    "blue": "#2F6BFF",
    "teal": "#18A999",
    "green": "#6BBF59",
    "orange": "#F29E4C",
    "red": "#E45756",
    "purple": "#7B61FF",
    "gray": "#6E7781",
    "ink": "#1F2937",
}

def savefig(name):
    path = out_dir / name
    plt.tight_layout(pad=0.6)
    plt.savefig(path, bbox_inches="tight")
    plt.close()

def pick_col(df: pd.DataFrame, candidates):
    """Return first existing column name from candidates list."""
    for c in candidates:
        if c in df.columns:
            return c
    return None

def require_col(df: pd.DataFrame, candidates, what: str):
    c = pick_col(df, candidates)
    if c is None:
        raise KeyError(f"Could not find a column for '{what}'. Tried: {candidates}. Available: {list(df.columns)[:40]} ...")
    return c

def norm_key(s):
    return re.sub(r"[^a-z0-9]+", "", str(s).strip().lower())

def fuzzy_pick(df: pd.DataFrame, candidates_norm):
    """Pick by normalized string match (useful when raw has slightly different capitalization)."""
    norm_map = {norm_key(c): c for c in df.columns}
    for cn in candidates_norm:
        if cn in norm_map:
            return norm_map[cn]
    return None

# ---- Schema detection for raw ----
col_season = pick_col(raw, ["season","Season","SEASON"]) or fuzzy_pick(raw, ["season"])
col_name = pick_col(raw, ["celebrity_name","Celebrity","celebrity","name","contestant","contestant_name"]) or fuzzy_pick(raw, ["celebrityname","contestantname","name"])
col_place = pick_col(raw, ["placement","final_placement","place","rank","final_rank"]) or fuzzy_pick(raw, ["placement","finalplacement","finalrank"])
col_industry = pick_col(raw, ["celebrity_industry","industry","CelebrityIndustry","celebrity_industry_name"]) or fuzzy_pick(raw, ["celebrityindustry","industry"])
col_age = pick_col(raw, ["celebrity_age_during_season","age","CelebrityAge","celebrity_age"]) or fuzzy_pick(raw, ["celebrityageduringseason","celebrityage","age"])

if col_season is None:
    raise KeyError("Raw dataset must include a season column (e.g., 'season').")
if col_name is None:
    raise KeyError("Raw dataset must include a contestant/name column (e.g., 'celebrity_name').")

# ---- Judge score reshaping (robust) ----
week_cols = [c for c in raw.columns if re.match(r"week\d+_judge\d+_score", str(c))]
if len(week_cols) == 0:
    # Some datasets may store judge scores as weekX_judgeY_score_total or similar; fall back to broader pattern.
    week_cols = [c for c in raw.columns if re.match(r"week\d+_judge\d+_.*score", str(c).lower())]

weeks = sorted({int(re.findall(r"week(\d+)_", str(c))[0]) for c in week_cols}) if week_cols else []
judges = sorted({int(re.findall(r"_judge(\d+)_", str(c))[0]) for c in week_cols}) if week_cols else []

long_rows = []
if weeks and judges:
    for _, r in raw.iterrows():
        for w in weeks:
            cols = [c for c in raw.columns if re.match(fr"week{w}_judge\d+_.*score", str(c).lower())]
            vals = [pd.to_numeric(r.get(c, np.nan), errors="coerce") for c in cols]
            vals = [v for v in vals if pd.notna(v)]
            judge_total = float(np.sum(vals)) if len(vals) else np.nan
            active = (len(vals) > 0) and (np.nanmax(vals) > 0)
            long_rows.append({
                "season": int(r[col_season]),
                "week": int(w),
                "celebrity_name": r[col_name],
                "industry": (r[col_industry] if col_industry else np.nan),
                "age": (r[col_age] if col_age else np.nan),
                "judge_total": judge_total if active else 0.0,
                "active": bool(active),
            })
judge_long = pd.DataFrame(long_rows) if long_rows else pd.DataFrame(columns=["season","week","celebrity_name","industry","age","judge_total","active"])

# If we couldn't build judge_long from raw, fall back to task1 (it already contains judge_total/judge_percent)
if judge_long.empty and {"season","week","celebrity_name","judge_total"}.issubset(task1.columns):
    tmp = task1[["season","week","celebrity_name","judge_total","industry","age"]].copy()
    tmp["active"] = True
    judge_long = tmp.rename(columns={"industry":"industry","age":"age"})

active_counts = judge_long.groupby(["season","week"])["active"].sum().reset_index(name="n_active") if not judge_long.empty else pd.DataFrame()

# ---- fig01 participation heatmap ----
if not active_counts.empty:
    pivot = active_counts.pivot(index="season", columns="week", values="n_active").sort_index()
    plt.figure(figsize=(8.2, 6.2))
    plt.imshow(pivot.values, aspect="auto", interpolation="nearest", cmap="viridis")
    plt.colorbar(label="Active contestants (count)")
    plt.yticks(np.arange(len(pivot.index)), pivot.index)
    plt.xticks(np.arange(len(pivot.columns)), pivot.columns)
    plt.xlabel("Week"); plt.ylabel("Season")
    savefig("fig01_participation_heatmap.png")

# ---- fig02 judge total score distribution ----
if not judge_long.empty and "active" in judge_long.columns:
    jt = pd.to_numeric(judge_long.loc[judge_long["active"], "judge_total"], errors="coerce").dropna()
    if len(jt):
        plt.figure(figsize=(7.2, 4.2))
        plt.hist(jt, bins=30, density=True, alpha=0.85, color=palette["blue"], edgecolor="white", linewidth=0.6)
        hist, edges = np.histogram(jt, bins=40, density=True)
        centers = (edges[:-1]+edges[1:])/2
        kernel = np.exp(-0.5*((np.arange(-6,7))/2.0)**2); kernel = kernel/kernel.sum()
        smooth = np.convolve(hist, kernel, mode="same")
        plt.plot(centers, smooth, color=palette["ink"], linewidth=2.0, alpha=0.9)
        plt.xlabel("Judge total score (active weeks)"); plt.ylabel("Density")
        savefig("fig02_judge_score_distribution.png")

# ---- Placement mapping (or fallback ranking proxy) ----
place_map = None
if col_place is not None:
    place_map = raw[[col_season, col_name, col_place]].copy()
    place_map.columns = ["season","celebrity_name","placement"]
    place_map["placement"] = pd.to_numeric(place_map["placement"], errors="coerce")
else:
    # fallback: approximate "placement" by final-week fan_share_mean rank within season (lower is better)
    if {"season","week","celebrity_name","fan_share_mean"}.issubset(task1.columns):
        last_week = task1.groupby(["season"])["week"].max().reset_index().rename(columns={"week":"last_week"})
        tmp = task1.merge(last_week, on="season", how="left")
        tmp = tmp[tmp["week"] == tmp["last_week"]].copy()
        tmp["placement"] = tmp.groupby("season")["fan_share_mean"].rank(ascending=False, method="first")
        place_map = tmp[["season","celebrity_name","placement"]]

# ---- fig03 judge trajectory by placement quartile ----
if (place_map is not None) and (not judge_long.empty):
    tmp = place_map.copy()
    tmp["place_q"] = tmp.groupby("season")["placement"].transform(
        lambda s: pd.qcut(s.rank(method="first"), 4, labels=["Q1(best)","Q2","Q3","Q4(worst)"])
    )
    jl = judge_long.merge(tmp[["season","celebrity_name","place_q"]], on=["season","celebrity_name"], how="left")
    traj = jl[jl["active"]].groupby(["week","place_q"])["judge_total"].mean().reset_index()
    if not traj.empty:
        plt.figure(figsize=(7.8, 4.6))
        for label, col in zip(["Q1(best)","Q2","Q3","Q4(worst)"], [palette["teal"], palette["green"], palette["orange"], palette["red"]]):
            sub = traj[traj["place_q"]==label]
            if not sub.empty:
                plt.plot(sub["week"], sub["judge_total"], marker="o", linewidth=2.0, color=col, label=label, alpha=0.95)
        plt.xlabel("Week"); plt.ylabel("Mean judge total")
        plt.legend(ncol=4, frameon=False, loc="upper left")
        savefig("fig03_judge_trajectory_by_placement_quartile.png")

# ---- fan heatmaps ----
def fan_heatmap_for_season(season, filename):
    if "season" not in task1.columns:
        return
    sub = task1[task1["season"]==season].copy()
    if sub.empty:
        return

    # sorting order: placement if available, else (final-week fan share rank), else alphabetical
    order = None
    if place_map is not None:
        pmap = place_map[place_map["season"]==season].copy()
        sub2 = sub.merge(pmap, on=["season","celebrity_name"], how="left")
        if "placement" in sub2.columns and sub2["placement"].notna().any():
            order = sub2.drop_duplicates("celebrity_name").sort_values(["placement","celebrity_name"], ascending=[True, True])["celebrity_name"]
    if order is None:
        # fallback: rank by last-week fan_share_mean
        lw = sub.groupby("celebrity_name")["week"].max().rename("last_week")
        sub2 = sub.merge(lw, on="celebrity_name", how="left")
        sub2 = sub2[sub2["week"]==sub2["last_week"]].copy()
        sub2["placement"] = sub2["fan_share_mean"].rank(ascending=False, method="first")
        order = sub2.sort_values(["placement","celebrity_name"])[["celebrity_name"]]["celebrity_name"]

    mat = sub.pivot_table(index="celebrity_name", columns="week", values="fan_share_mean", aggfunc="mean")
    mat = mat.reindex(order)

    plt.figure(figsize=(8.2, max(4.6, 0.22*len(mat.index)+1.5)))
    plt.imshow(mat.values, aspect="auto", interpolation="nearest", cmap="magma")
    plt.colorbar(label="Estimated fan vote share (posterior mean)")
    plt.yticks(np.arange(len(mat.index)), mat.index)
    plt.xticks(np.arange(len(mat.columns)), mat.columns)
    plt.xlabel("Week"); plt.ylabel("Contestant (sorted by final performance)")
    savefig(filename)

for s in [1,2,10,20,27,34]:
    fan_heatmap_for_season(s, f"fig_fan_share_heatmap_season{s:02d}.png")

# ---- uncertainty snapshot (top controversy) ----
if "controversy_score" in task1.columns:
    top_c = task1.sort_values("controversy_score", ascending=False).dropna(subset=["controversy_score"]).head(1)
    if len(top_c):
        ss, ww = int(top_c.iloc[0]["season"]), int(top_c.iloc[0]["week"])
        sub = task1[(task1["season"]==ss)&(task1["week"]==ww)].copy().sort_values("fan_share_mean", ascending=False)
        plt.figure(figsize=(8.4, max(4.2, 0.18*len(sub)+2.0)))
        y = np.arange(len(sub))
        plt.barh(y, sub["fan_share_mean"], color=palette["blue"], alpha=0.75, edgecolor="white", linewidth=0.5)
        xerr = np.vstack([sub["fan_share_mean"]-sub["fan_share_ci_low"], sub["fan_share_ci_high"]-sub["fan_share_mean"]])
        plt.errorbar(sub["fan_share_mean"], y, xerr=xerr, fmt="none", ecolor=palette["ink"], elinewidth=1.2, capsize=2.5, alpha=0.9)
        if "elim_this_week" in sub.columns:
            for i, is_elim in enumerate(sub["elim_this_week"].astype(bool).values):
                if is_elim:
                    plt.scatter([sub.iloc[i]["fan_share_mean"]], [i], s=70, color=palette["red"], zorder=4)
        plt.yticks(y, sub["celebrity_name"]); plt.gca().invert_yaxis()
        plt.xlabel("Fan vote share (mean ± 95% CI)")
        savefig("fig_uncertainty_snapshot_top_controversy.png")

# ---- controversy heatmap ----
if {"season","week","controversy_score"}.issubset(task1.columns):
    cw = task1.groupby(["season","week"])["controversy_score"].mean().reset_index()
    mat = cw.pivot(index="season", columns="week", values="controversy_score").sort_index()
    plt.figure(figsize=(8.2, 6.2))
    plt.imshow(mat.values, aspect="auto", interpolation="nearest", cmap="plasma")
    plt.colorbar(label="Controversy score")
    plt.yticks(np.arange(len(mat.index)), mat.index)
    plt.xticks(np.arange(len(mat.columns)), mat.columns)
    plt.xlabel("Week"); plt.ylabel("Season")
    savefig("fig11_controversy_heatmap.png")

# ---- rank gap ----
if {"season","week","fan_share_mean","judge_percent"}.issubset(task1.columns):
    t = task1.copy()
    t["fan_rank"] = t.groupby(["season","week"])["fan_share_mean"].rank(ascending=False, method="average")
    t["judge_rank"] = t.groupby(["season","week"])["judge_percent"].rank(ascending=False, method="average")
    gap = (t["judge_rank"] - t["fan_rank"]).dropna()
    plt.figure(figsize=(7.4, 4.2))
    plt.hist(gap, bins=31, color=palette["purple"], alpha=0.78, edgecolor="white", linewidth=0.6)
    plt.xlabel("Rank gap = judge_rank - fan_rank"); plt.ylabel("Count")
    savefig("fig12_rank_gap_hist.png")
else:
    t = task1.copy()

# ---- industry boxplot ----
if "industry" in task1.columns and "fan_share_mean" in task1.columns:
    ind_counts = task1["industry"].value_counts()
    top_inds = ind_counts[ind_counts>=50].index[:10]
    sub = task1[task1["industry"].isin(top_inds)].copy()
    if not sub.empty:
        order = sub.groupby("industry")["fan_share_mean"].median().sort_values(ascending=False).index.tolist()
        data = [sub[sub["industry"]==i]["fan_share_mean"].values for i in order]
        plt.figure(figsize=(9.0, 4.8))
        bp = plt.boxplot(data, labels=order, vert=True, patch_artist=True, showfliers=False)
        cols = [palette["blue"], palette["teal"], palette["green"], palette["orange"], palette["red"],
                palette["purple"], "#8AB4F8", "#A7F3D0", "#FBCFE8", "#FDE68A"]
        for patch, col in zip(bp["boxes"], cols):
            patch.set_facecolor(col); patch.set_alpha(0.55); patch.set_edgecolor("white")
        for median in bp["medians"]:
            median.set_color(palette["ink"]); median.set_linewidth(1.8)
        plt.ylabel("Fan vote share (posterior mean)")
        plt.xticks(rotation=25, ha="right")
        savefig("fig13_industry_boxplot_fan_share.png")

# ---- industry forest ----
if {"coef","se","industry"}.issubset(task3.columns):
    coef = task3.sort_values("coef", ascending=True).copy()
    plt.figure(figsize=(8.6, max(4.6, 0.20*len(coef)+1.2)))
    y = np.arange(len(coef))
    plt.axvline(0, color=palette["gray"], linewidth=1.2, alpha=0.65)
    plt.errorbar(coef["coef"], y, xerr=1.96*coef["se"], fmt="o", color=palette["ink"],
                ecolor=palette["gray"], elinewidth=1.3, capsize=2.5, alpha=0.95)
    colors = [palette["teal"] if v>0 else palette["red"] for v in coef["coef"]]
    plt.scatter(coef["coef"], y, s=50, c=colors, alpha=0.9, zorder=3)
    plt.yticks(y, coef["industry"])
    plt.xlabel("Industry effect on log(fan share)  (±95% CI)")
    savefig("fig14_industry_effect_forest.png")

# ---- flip vs controversy ----
if {"controversy_score","flip_prob_percent_vs_rank","n_active"}.issubset(task2p.columns):
    plt.figure(figsize=(7.6, 4.6))
    plt.scatter(task2p["controversy_score"], task2p["flip_prob_percent_vs_rank"], s=26,
                c=task2p["n_active"], cmap="viridis", alpha=0.85, edgecolors="none")
    cbar = plt.colorbar(); cbar.set_label("Active contestants")
    plt.xlabel("Controversy score")
    plt.ylabel("Flip probability: Percent vs Rank")
    savefig("fig15_flipprob_vs_controversy.png")

# ---- match rates by scheme (robust) ----
scheme_by_season = None
if "scheme_assumed" in task1.columns:
    scheme_by_season = task1.groupby("season")["scheme_assumed"].agg(lambda s: s.mode().iloc[0] if not s.mode().empty else s.iloc[0])

def _matchrate_from_deterministic(df):
    # Accept either already-computed match columns or compute from predicted elimination labels
    cols_match = {"percent_match","rank_match","bottom2save_match"}
    if cols_match.issubset(df.columns):
        return df[list(cols_match)].copy()
    if {"actual_elim","percent_elim","rank_elim","bottom2save_elim"}.issubset(df.columns):
        out = pd.DataFrame()
        out["percent_match"] = (df["percent_elim"] == df["actual_elim"]).astype(float)
        out["rank_match"] = (df["rank_elim"] == df["actual_elim"]).astype(float)
        out["bottom2save_match"] = (df["bottom2save_elim"] == df["actual_elim"]).astype(float)
        return out
    return None

grp = None
if scheme_by_season is not None:
    mdet = _matchrate_from_deterministic(task2d)
    if mdet is not None:
        g = task2d.copy()
        g["scheme"] = g["season"].map(scheme_by_season)
        g = pd.concat([g, mdet], axis=1)
        grp = g.groupby("scheme")[["percent_match","rank_match","bottom2save_match"]].mean().reset_index()
    else:
        if {"prob_actual_under_percent","prob_actual_under_rank","prob_actual_under_bottom2"}.issubset(task2p.columns):
            g = task2p.copy()
            g["scheme"] = g["season"].map(scheme_by_season)
            g["percent_match"] = pd.to_numeric(g["prob_actual_under_percent"], errors="coerce")
            g["rank_match"] = pd.to_numeric(g["prob_actual_under_rank"], errors="coerce")
            g["bottom2save_match"] = pd.to_numeric(g["prob_actual_under_bottom2"], errors="coerce")
            grp = g.groupby("scheme")[["percent_match","rank_match","bottom2save_match"]].mean().reset_index()

if grp is not None and len(grp):
    plt.figure(figsize=(7.4, 4.4))
    x = np.arange(len(grp)); w = 0.24
    plt.bar(x-w, grp["percent_match"], width=w, color=palette["blue"], alpha=0.75, label="Percent matches actual")
    plt.bar(x,   grp["rank_match"], width=w, color=palette["orange"], alpha=0.75, label="Rank matches actual")
    plt.bar(x+w, grp["bottom2save_match"], width=w, color=palette["teal"], alpha=0.75, label="Bottom-2+Save matches actual")
    plt.xticks(x, grp["scheme"])
    plt.ylim(0, 1.05)
    plt.ylabel("Match rate")
    plt.legend(frameon=False, loc="upper right")
    savefig("fig16_matchrate_by_scheme.png")

# ---- fairness heatmap (robust to different percentile column names) ----
grid = task4.copy()

# Older bundles used max_elim_percentile; current bundle may have avg_elim_judge_percentile / avg_elim_fan_percentile.
if "max_elim_percentile" not in grid.columns:
    c_j = pick_col(grid, ["avg_elim_judge_percentile","max_elim_judge_percentile","elim_judge_percentile"])
    c_f = pick_col(grid, ["avg_elim_fan_percentile","max_elim_fan_percentile","elim_fan_percentile"])
    if (c_j is not None) and (c_f is not None):
        grid["max_elim_percentile"] = grid[[c_j, c_f]].max(axis=1)
    elif c_j is not None:
        grid["max_elim_percentile"] = grid[c_j]
    elif c_f is not None:
        grid["max_elim_percentile"] = grid[c_f]

if {"lambda","alpha_fan","max_elim_percentile"}.issubset(grid.columns):
    lam = np.sort(grid["lambda"].unique()); alp = np.sort(grid["alpha_fan"].unique())
    M = grid.pivot(index="alpha_fan", columns="lambda", values="max_elim_percentile").reindex(index=alp, columns=lam)
    plt.figure(figsize=(7.6, 5.2))
    plt.imshow(M.values, aspect="auto", interpolation="nearest", cmap="cividis")
    plt.colorbar(label="Max(elim percentile)")
    plt.xticks(np.arange(len(lam)), [f"{v:.2f}" for v in lam], rotation=45, ha="right")
    plt.yticks(np.arange(len(alp)), [f"{v:.2f}" for v in alp])
    plt.xlabel("λ"); plt.ylabel("α")
    savefig("fig17_fairness_grid_heatmap.png")

# ---- pareto frontier ----
if {"upset_rate_judge","upset_rate_fan"}.issubset(grid.columns) and {"upset_rate_judge","upset_rate_fan"}.issubset(pareto.columns):
    plt.figure(figsize=(7.0, 4.6))
    plt.scatter(grid["upset_rate_judge"], grid["upset_rate_fan"], s=24, color=palette["gray"], alpha=0.35, label="All grid points")
    plt.scatter(pareto["upset_rate_judge"], pareto["upset_rate_fan"], s=55, color=palette["purple"], alpha=0.9, label="Pareto frontier")
    plt.xlabel("Upset rate vs judges"); plt.ylabel("Upset rate vs fans")
    plt.legend(frameon=False, loc="upper right")
    savefig("fig18_pareto_frontier_upset.png")


# =========================
# Load fairness grid results
# =========================
from pathlib import Path
grid = pd.read_csv(Path(args.results_dir) / "task4_fairness_grid.csv")


# =========================
# Style
# =========================
mpl.rcParams.update({
    "figure.dpi": 220,
    "savefig.dpi": 300,
    "font.size": 10,
    "axes.spines.top": False,
    "axes.spines.right": False,
    "axes.grid": True,
    "grid.alpha": 0.18,
})

palette = ["#2F6BFF", "#18A999", "#6BBF59", "#F29E4C", "#E45756"]
alpha_pick = [0.50, 0.60, 0.70, 0.90, 1.00]

# ============================================================
# Improved Fig19 (Delta): marginal change vs baseline lambda
# ============================================================

# ============================================================
# Improved Fig19 (Delta): marginal change vs baseline lambda
# ============================================================

if {"avg_elim_fan_percentile", "lambda", "alpha_fan"}.issubset(grid.columns):

    plt.figure(figsize=(7.8, 4.8))

    # Representative alpha levels
    alpha_pick = [0.50, 0.60, 0.70, 0.90, 1.00]

    # Safe color list (no palette dict needed)
    colors_for = ["#2F6BFF", "#18A999", "#6BBF59", "#F29E4C", "#E45756"]

    for a, col in zip(alpha_pick, colors_for):
        sub = grid[grid["alpha_fan"] == a].sort_values("lambda")

        # Baseline at smallest lambda
        base = float(sub.iloc[0]["avg_elim_fan_percentile"])

        plt.plot(
            sub["lambda"],
            sub["avg_elim_fan_percentile"] - base,
            marker="o",
            linewidth=2.2,
            alpha=0.92,
            color=col,
            label=f"α={a:.2f}"
        )

    # Reference line
    plt.axhline(0, color="gray", linewidth=1.2, alpha=0.6)

    plt.xlabel("λ  (fan weight)")
    plt.ylabel("Δ eliminated fan-percentile (vs smallest λ)")
    plt.legend(frameon=False, ncol=3, loc="upper right")

    savefig("fig19_improved_delta.png")