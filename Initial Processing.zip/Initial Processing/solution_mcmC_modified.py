"""
MCM/ICM 2026 Problem C (DWTS) — Task 1–4 End-to-End Solution
==========================================================

This script:
1) Loads 2026_MCM_Problem_C_Data.csv
2) Infers weekly fan vote shares (Task 1)
   - Bayesian-style sequential model (Dirichlet prior + elimination likelihood)
   - Produces posterior mean/sd/credible interval + "controversy score" per week
   - Produces a deterministic "point estimate" that is consistent with eliminations
     (max-entropy KL projection for Percent seasons; rank-construction for Rank seasons)
3) Compares Rank vs Percent vs Bottom-2+Judge-Save counterfactuals (Task 2)
   - Deterministic comparison with posterior mean x
   - Probabilistic flip analysis with Dirichlet approximation (mean/sd -> concentration)
4) Quantifies feature effects (Task 3)
   - Regression of log fan share on judge %, age, industry, season FE
5) Designs a fairer mechanism and does a grid/Pareto search (Task 4)
   - Percent rule with concave fan transform x^alpha and adjustable lambda

Outputs are written to ./mcmC_results/

Run:
  python solution_mcmC.py --data 2026_MCM_Problem_C_Data.csv --out mcmC_results

"""

import argparse, os, re, math
import numpy as np
import pandas as pd
import matplotlib.pyplot as plt
from scipy.special import expit, logsumexp
from scipy.stats import rankdata
from scipy.optimize import minimize
import statsmodels.formula.api as smf
from sklearn.isotonic import IsotonicRegression

WEEKS = list(range(1, 12))

def parse_elim_week(res: str):
    m = re.search(r"Eliminated Week (\d+)", str(res))
    return int(m.group(1)) if m else None

def row_week_total(row, w: int) -> float:
    cols = [f"week{w}_judge1_score", f"week{w}_judge2_score", f"week{w}_judge3_score", f"week{w}_judge4_score"]
    vals = [row.get(c, np.nan) for c in cols]
    return float(np.nansum(vals))

def infer_withdraw_week(row) -> int|None:
    if str(row["results"]) != "Withdrew":
        return None
    totals = [row_week_total(row, w) for w in WEEKS]
    last = 0
    for w, tot in zip(WEEKS, totals):
        if tot > 0:
            last = w
    return last if last > 0 else None

def weighted_quantile(values, quantiles, sample_weight=None):
    values = np.asarray(values)
    if values.ndim == 1:
        values = values[:, None]
    n, d = values.shape
    if sample_weight is None:
        sample_weight = np.ones(n)
    sample_weight = np.asarray(sample_weight)
    qs = np.array(quantiles)
    out = np.zeros((len(qs), d))
    for j in range(d):
        v = values[:, j]
        idx = np.argsort(v)
        v_sorted = v[idx]
        w_sorted = sample_weight[idx]
        cum = np.cumsum(w_sorted)
        if cum[-1] == 0:
            out[:, j] = np.nan
            continue
        cum = cum / cum[-1]
        out[:, j] = np.interp(qs, cum, v_sorted)
    return out

def prior_pi(pJ, x_prev=None, rho=0.7, gamma=1.2, eps=1e-6):
    z = (pJ - pJ.mean()) / (pJ.std() + 1e-9)
    base = np.exp(gamma * z)
    if x_prev is not None:
        base = base * np.power(x_prev + eps, rho)
    return base / base.sum()

def percent_log_likelihood(X, pJ, elim_idx, tau=30.0, lam=0.5):
    M, N = X.shape
    if len(elim_idx) == 0 or N == 1:
        return np.zeros(M)
    S = (1 - lam) * pJ[None, :] + lam * X
    elim = set(elim_idx)
    surv = [j for j in range(N) if j not in elim]
    if len(surv) == 0:
        return np.zeros(M)
    logL = np.zeros(M)
    for i in elim_idx:
        diff = S[:, surv] - S[:, i][:, None]
        log_prob = -np.logaddexp(0, -tau * diff)  # log(sigmoid(tau*diff))
        logL += log_prob.sum(axis=1)
    return logL

def rank_log_likelihood(X, J, elim_idx, tau=7.0):
    M, N = X.shape
    if len(elim_idx) == 0 or N == 1:
        return np.zeros(M)
    rJ = rankdata(-J, method="average")
    order = np.argsort(-X, axis=1)
    rV = np.empty_like(order, dtype=float)
    rV[np.arange(M)[:, None], order] = np.arange(1, N + 1, dtype=float)[None, :]
    R = rV + rJ[None, :]
    elim = set(elim_idx)
    surv = [j for j in range(N) if j not in elim]
    if len(surv) == 0:
        return np.zeros(M)
    logL = np.zeros(M)
    for i in elim_idx:
        diff = R[:, i][:, None] - R[:, surv]
        log_prob = -np.logaddexp(0, -tau * diff)
        logL += log_prob.sum(axis=1)
    return logL

def bottom2_save_log_likelihood(X, J, pJ, elim_idx, gamma=2.0, kappa=12.0, eps=1e-12):
    M, N = X.shape
    m = len(elim_idx)
    if m == 0 or N == 1:
        return np.zeros(M)
    if m >= 3:
        return rank_log_likelihood(X, J, elim_idx, tau=7.0)
    rJ = rankdata(-J, method="average")
    order = np.argsort(-X, axis=1)
    rV = np.empty_like(order, dtype=float)
    rV[np.arange(M)[:, None], order] = np.arange(1, N + 1, dtype=float)[None, :]
    R = rV + rJ[None, :]
    W = np.exp(gamma * R)
    Wsum = W.sum(axis=1) + eps
    if m == 2:
        i, j = elim_idx
        pi = W[:, i] / Wsum
        pj_cond = W[:, j] / (Wsum - W[:, i] + eps)
        p_ij = pi * pj_cond
        pj = W[:, j] / Wsum
        pi_cond = W[:, i] / (Wsum - W[:, j] + eps)
        p_ji = pj * pi_cond
        p = p_ij + p_ji + eps
        return np.log(p)
    else:
        e = elim_idx[0]
        pe = W[:, e] / Wsum
        Wsum_exe = Wsum - W[:, e] + eps
        p_ej = pe[:, None] * (W / Wsum_exe[:, None])
        pj = W / Wsum[:, None]
        Wsum_exj = Wsum[:, None] - W + eps
        p_je = pj * (W[:, e][:, None] / Wsum_exj)
        P_pair = p_ej + p_je
        P_pair[:, e] = 0.0
        judge_prob = expit(kappa * (pJ - pJ[e]))
        p_elim = (P_pair * judge_prob[None, :]).sum(axis=1) + eps
        return np.log(p_elim)

def kl_obj(x, pi):
    return float(np.sum(x * (np.log(x + 1e-15) - np.log(pi + 1e-15))))

def solve_percent_week(pi, pJ, elim_idx, lam=0.5, eps=1e-6):
    N = len(pi)
    if len(elim_idx) == 0 or N == 1:
        return pi.copy()
    elim = set(elim_idx)
    surv = [j for j in range(N) if j not in elim]
    cons = []
    cons.append({"type": "eq", "fun": lambda x: np.sum(x) - 1.0})
    for i in elim_idx:
        for j in surv:
            rhs = (1 - lam) * (pJ[j] - pJ[i])
            cons.append({"type": "ineq", "fun": lambda x, i=i, j=j, rhs=rhs: rhs - lam * (x[i] - x[j])})
    bounds = [(eps, 1.0) for _ in range(N)]
    x0 = pi.copy()
    res = minimize(kl_obj, x0, args=(pi,), method="SLSQP", bounds=bounds, constraints=cons,
                   options={"ftol": 1e-12, "maxiter": 1000, "disp": False})
    if not res.success:
        x = pi.copy()
        for i in elim_idx:
            x[i] = min(x[i], 0.01)
        return x / x.sum()
    x = np.clip(res.x, eps, 1.0)
    return x / x.sum()

def construct_rank_shares(pi, rV, eta=0.2, beta=3.0):
    N = len(pi)
    base = np.exp(-beta * (rV - 1))
    base = base / base.sum()
    x = (1 - eta) * base + eta * pi
    order = np.argsort(rV)
    ir = IsotonicRegression(increasing=False, out_of_bounds="clip")
    y = ir.fit_transform(np.arange(N), x[order])
    x2 = np.zeros(N)
    x2[order] = y
    x2 = x2 + 1e-8 * np.random.rand(N)
    x2 = np.clip(x2, 1e-12, None)
    return x2 / x2.sum()

def make_rank_point(pi, J, elim_idx, judge_save=False):
    N = len(pi)
    if len(elim_idx) == 0 or N == 1:
        return pi.copy()
    m = len(elim_idx)
    rJ = rankdata(-J, method="average")
    pJ = J / (J.sum() + 1e-12)
    elim = set(elim_idx)
    surv = [i for i in range(N) if i not in elim]

    surv_sorted = sorted(surv, key=lambda i: rJ[i], reverse=True)
    rV = np.zeros(N, dtype=int)
    for rank, i in enumerate(surv_sorted, start=1):
        rV[i] = rank
    for k, i in enumerate(sorted(elim_idx, key=lambda i: rJ[i])):
        rV[i] = N - m + 1 + k

    if judge_save and m == 1 and N >= 2:
        e = elim_idx[0]
        candidates = [j for j in range(N) if j != e and pJ[j] > pJ[e]]
        candidates_sorted = sorted(candidates, key=lambda j: (pi[j], -rJ[j]))
        for j in candidates_sorted[:N]:
            rV_try = rV.copy()
            rV_try[e] = N
            rV_try[j] = N - 1
            others = [k for k in range(N) if k not in [e, j]]
            others_sorted = sorted(others, key=lambda k: rJ[k], reverse=True)
            for rank, kidx in enumerate(others_sorted, start=1):
                rV_try[kidx] = rank
            R = rJ + rV_try
            bottom2 = set(np.argsort(-R)[:2])
            if e in bottom2 and j in bottom2:
                rV = rV_try
                break

    for attempt in range(6):
        eta = 0.25 * (0.5 ** attempt)
        beta = 2.5 + attempt
        x = construct_rank_shares(pi, rV, eta=eta, beta=beta)
        rV_x = rankdata(-x, method="average")
        R = rJ + rV_x
        if judge_save:
            bottom2 = list(np.argsort(-R)[:2]) if N >= 2 else [0]
            if m == 1 and N >= 2:
                i, j = bottom2
                pred = i if pJ[i] < pJ[j] else j
                if pred == elim_idx[0]:
                    return x
            else:
                pred_set = set(np.argsort(-R)[:m])
                if pred_set == set(elim_idx):
                    return x
        else:
            pred_set = set(np.argsort(-R)[:m])
            if pred_set == set(elim_idx):
                return x

    x = pi.copy()
    for i in elim_idx:
        x[i] = 1e-6
    return x / x.sum()

def gini(arr):
    x = np.array(arr, dtype=float)
    if np.all(x == 0):
        return 0.0
    x = np.sort(x)
    n = len(x)
    cum = np.cumsum(x)
    return float((n + 1 - 2 * np.sum(cum) / cum[-1]) / n)

def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--data", required=True)
    ap.add_argument("--out", default="mcmC_results")
    ap.add_argument("--seed", type=int, default=42)
    args = ap.parse_args()

    np.random.seed(args.seed)
    os.makedirs(args.out, exist_ok=True)

    df = pd.read_csv(args.data)

    # parse elimination / withdraw
    df["elim_week"] = df["results"].apply(parse_elim_week)
    df["withdraw_week"] = df.apply(infer_withdraw_week, axis=1)
    df["elim_week2"] = df["elim_week"].fillna(df["withdraw_week"])

    # season lengths
    week_cols = [c for c in df.columns if c.startswith("week") and c.endswith("_score")]
    season_weeks = {}
    for s, sdf in df.groupby("season"):
        maxw = 0
        for w in WEEKS:
            cols = [c for c in week_cols if c.startswith(f"week{w}_")]
            if sdf[cols].notna().any().any():
                maxw = w
        season_weeks[int(s)] = int(maxw)

    # long
    rec=[]
    for _, row in df.iterrows():
        s = int(row["season"])
        T = season_weeks[s]
        for w in range(1, T+1):
            J = row_week_total(row, w)
            rec.append({
                "season": s, "week": w, "celebrity_name": row["celebrity_name"],
                "industry": row["celebrity_industry"],
                "age": row["celebrity_age_during_season"],
                "homecountry": row["celebrity_homecountry/region"],
                "placement": row["placement"],
                "results": row["results"],
                "elim_week": row["elim_week2"],
                "judge_total": J,
                "active": J>0
            })
    long = pd.DataFrame.from_records(rec)

    # elimination events
    elim_events = {(s,w): df[(df["season"]==s) & (df["elim_week2"]==w)]["celebrity_name"].tolist()
                  for s in season_weeks.keys()
                  for w in range(1, season_weeks[s]+1)}

    # Model parameters
    LAM=0.5
    ALPHA=60.0
    RHO=0.7
    GAMMA_PRIOR=1.2
    TAU_PERCENT=30.0
    TAU_RANK=7.0
    GAMMA_BOTTOM=2.0
    KAPPA_SAVE=12.0
    M_PARTICLES=2500

    # Sequential inference
    rows=[]
    week_rows=[]
    for season in sorted(season_weeks.keys()):
        T = season_weeks[season]
        scheme = "percent" if 3<=season<=27 else "rank"
        judge_save = (season>=28)
        x_prev=None; prev_names=None
        for week in range(1, T+1):
            wd = long[(long["season"]==season) & (long["week"]==week) & (long["active"])]
            names = wd["celebrity_name"].tolist()
            J = wd["judge_total"].values.astype(float)
            N = len(names)
            if N==0:
                continue
            pJ = J/(J.sum()+1e-12)

            if x_prev is None:
                x_prev_curr=None
            else:
                prev_map={n:x_prev[i] for i,n in enumerate(prev_names)}
                x_prev_curr=np.array([prev_map.get(n,0.0) for n in names],dtype=float)
                if x_prev_curr.sum()>0:
                    x_prev_curr=x_prev_curr/x_prev_curr.sum()
                else:
                    x_prev_curr=None

            pi = prior_pi(pJ, x_prev_curr, rho=RHO, gamma=GAMMA_PRIOR)

            elim_names = [n for n in elim_events.get((season,week),[]) if n in names]
            elim_idx = [names.index(n) for n in elim_names]

            if N==1:
                x_mean=np.array([1.0]); x_map=np.array([1.0])
                sd=np.array([0.0]); ci_low=np.array([1.0]); ci_high=np.array([1.0])
                ess=1.0; logZ=0.0
            else:
                alpha_vec=np.maximum(ALPHA*pi,1e-3)
                X=np.random.dirichlet(alpha_vec,size=M_PARTICLES)
                if len(elim_idx)==0:
                    logL=np.zeros(M_PARTICLES)
                else:
                    if scheme=="percent":
                        logL=percent_log_likelihood(X,pJ,elim_idx,tau=TAU_PERCENT,lam=LAM)
                    else:
                        if judge_save:
                            logL=bottom2_save_log_likelihood(X,J,pJ,elim_idx,gamma=GAMMA_BOTTOM,kappa=KAPPA_SAVE)
                        else:
                            logL=rank_log_likelihood(X,J,elim_idx,tau=TAU_RANK)

                logZ = logsumexp(logL) - math.log(M_PARTICLES)
                logw = logL - logsumexp(logL)
                weights = np.exp(logw)
                ess = 1/np.sum(weights**2)
                x_mean = (weights[:,None]*X).sum(axis=0)
                x_map = X[int(np.argmax(logw))]
                var = (weights[:,None]*(X-x_mean[None,:])**2).sum(axis=0)
                sd = np.sqrt(var)
                qs = weighted_quantile(X,[0.025,0.975],sample_weight=weights)
                ci_low, ci_high = qs[0], qs[1]

            # point estimate consistent with eliminations (when possible)
            if scheme=="percent":
                x_point = solve_percent_week(pi, pJ, elim_idx, lam=LAM)
            else:
                x_point = make_rank_point(pi, J, elim_idx, judge_save=judge_save)

            for i,nm in enumerate(names):
                rows.append({
                    "season": season, "week": week, "celebrity_name": nm,
                    "industry": wd["industry"].iloc[i],
                    "age": wd["age"].iloc[i],
                    "homecountry": wd["homecountry"].iloc[i],
                    "scheme_assumed": scheme + ("+save" if judge_save and scheme=="rank" else ""),
                    "judge_total": float(J[i]),
                    "judge_percent": float(pJ[i]),
                    "fan_share_mean": float(x_mean[i]),
                    "fan_share_map": float(x_map[i]),
                    "fan_share_point": float(x_point[i]),
                    "fan_share_sd": float(sd[i]),
                    "fan_share_ci_low": float(ci_low[i]),
                    "fan_share_ci_high": float(ci_high[i]),
                    "elim_this_week": int(nm in elim_names),
                    "n_active": int(N),
                    "predictive_prob": float(np.exp(logZ)),
                    "log_predictive_prob": float(logZ),
                    "ess": float(ess),
                    "prior_mean": float(pi[i]),
                    "controversy_score": float(-logZ if len(elim_idx)>0 else 0.0)
                })

            week_rows.append({
                "season": season, "week": week,
                "scheme_assumed": scheme + ("+save" if judge_save and scheme=="rank" else ""),
                "n_active": int(N),
                "n_elim": int(len(elim_idx)),
                "predictive_prob": float(np.exp(logZ)),
                "log_predictive_prob": float(logZ),
                "ess": float(ess),
                "controversy_score": float(-logZ if len(elim_idx)>0 else 0.0)
            })

            x_prev=x_mean
            prev_names=names

    res = pd.DataFrame(rows)
    week_summary = pd.DataFrame(week_rows).groupby(["season","week"]).first().reset_index()

    # Save task 1
    res.to_csv(os.path.join(args.out, "task1_fan_vote_estimates.csv"), index=False)
    week_summary.to_csv(os.path.join(args.out, "task1_week_summary.csv"), index=False)

    # Task 2 deterministic comparison with posterior mean x
    def elim_percent(names, J, x, m=1, lam=0.5):
        pJ=J/(J.sum()+1e-12)
        S=(1-lam)*pJ + lam*x
        idx=np.argsort(S)[:m]
        return [names[i] for i in idx]

    def elim_rank(names, J, x, m=1):
        rJ=rankdata(-J, method="average")
        rV=rankdata(-x, method="average")
        R=rJ+rV
        idx=np.argsort(-R)[:m]
        return [names[i] for i in idx]

    def elim_bottom2_save(names, J, x, m=1):
        pJ=J/(J.sum()+1e-12)
        rJ=rankdata(-J, method="average")
        rV=rankdata(-x, method="average")
        R=rJ+rV
        if len(names)==1:
            return [names[0]]
        bottom2=np.argsort(-R)[:2]
        if m==1:
            i,j=bottom2
            e=i if pJ[i]<pJ[j] else j
            return [names[e]]
        return [names[i] for i in bottom2[:m]]

    comp=[]
    for (season,week), g in res.groupby(["season","week"]):
        names=g["celebrity_name"].tolist()
        J=g["judge_total"].values.astype(float)
        x=g["fan_share_mean"].values.astype(float)
        actual=[n for n in elim_events.get((season,week),[]) if n in names]
        m=len(actual)
        if m==0:
            continue
        comp.append({
            "season": season, "week": week, "n_active": len(names), "m_elim": m,
            "actual_elim": "|".join(actual),
            "percent_elim": "|".join(elim_percent(names,J,x,m=m,lam=LAM)),
            "rank_elim": "|".join(elim_rank(names,J,x,m=m)),
            "bottom2save_elim": "|".join(elim_bottom2_save(names,J,x,m=m)),
        })
    comp_df=pd.DataFrame(comp)
    comp_df.to_csv(os.path.join(args.out, "task2_rule_comparison_deterministic.csv"), index=False)

    # -----------------------------
    # Task 2 (Probabilistic): flip probabilities via Dirichlet posterior approximation
    # -----------------------------
    def estimate_dirichlet_concentration(mu, sd, min_a0=10.0, max_a0=2000.0):
        """
        Approximate Dirichlet total concentration a0 from mean mu and std sd.
        Dirichlet variance: Var[x_i] = mu_i(1-mu_i)/(a0+1)
        => a0_i = mu_i(1-mu_i)/Var_i - 1
        We aggregate across i using a robust median.
        """
        mu = np.asarray(mu, dtype=float)
        sd = np.asarray(sd, dtype=float)
        var = np.maximum(sd**2, 1e-10)

        # Avoid degenerate mu
        mu = np.clip(mu, 1e-8, 1.0)
        mu = mu / (mu.sum() + 1e-12)

        a0_i = mu * (1 - mu) / var - 1.0
        a0_i = a0_i[np.isfinite(a0_i)]
        if len(a0_i) == 0:
            return 60.0
        # robust aggregation
        a0 = float(np.median(a0_i))
        if not np.isfinite(a0):
            a0 = 60.0
        return float(np.clip(a0, min_a0, max_a0))

    def sample_dirichlet_from_mean_sd(mu, sd, n_sims=1500):
        mu = np.asarray(mu, dtype=float)
        mu = np.clip(mu, 1e-8, 1.0)
        mu = mu / (mu.sum() + 1e-12)

        a0 = estimate_dirichlet_concentration(mu, sd)
        alpha_vec = np.maximum(a0 * mu, 1e-6)
        return np.random.dirichlet(alpha_vec, size=n_sims)

    # reuse deterministic elimination helpers already defined above:
    # elim_percent(names, J, x, m=1, lam=LAM)
    # elim_rank(names, J, x, m=1)
    # elim_bottom2_save(names, J, x, m=1)

    prob_rows = []
    N_SIMS = 2000  # you can increase to 5000 for smoother probabilities

    # iterate only weeks with eliminations (m>0)
    for (season, week), g in res.groupby(["season", "week"]):
        names = g["celebrity_name"].tolist()
        J = g["judge_total"].values.astype(float)
        mu = g["fan_share_mean"].values.astype(float)

        # if sd missing/zero, fall back to a small uncertainty so sampling still works
        if "fan_share_sd" in g.columns:
            sd = g["fan_share_sd"].values.astype(float)
        else:
            sd = np.full_like(mu, 0.05, dtype=float)
        sd = np.where(np.isfinite(sd) & (sd > 0), sd, 0.05)

        # actual eliminated set this week
        actual = [n for n in elim_events.get((season, week), []) if n in names]
        m = len(actual)
        if m == 0:
            continue

        # map actual to a set for quick compare
        actual_set = set(actual)

        # posterior draws (Dirichlet approx)
        Xs = sample_dirichlet_from_mean_sd(mu, sd, n_sims=N_SIMS)

        flip_pr = 0
        flip_pb = 0
        flip_rb = 0

        match_obs_percent = 0
        match_obs_rank = 0
        match_obs_bottom2save = 0

        for sidx in range(N_SIMS):
            x_draw = Xs[sidx, :]

            eP = set(elim_percent(names, J, x_draw, m=m, lam=LAM))
            eR = set(elim_rank(names, J, x_draw, m=m))
            eB = set(elim_bottom2_save(names, J, x_draw, m=m))

            if eP != eR:
                flip_pr += 1
            if eP != eB:
                flip_pb += 1
            if eR != eB:
                flip_rb += 1

            if eP == actual_set:
                match_obs_percent += 1
            if eR == actual_set:
                match_obs_rank += 1
            if eB == actual_set:
                match_obs_bottom2save += 1

        prob_rows.append({
            "season": int(season),
            "week": int(week),
            "n_active": int(len(names)),
            "m_elim": int(m),
            "actual_elim": "|".join(actual),

            "flip_prob_percent_vs_rank": flip_pr / N_SIMS,
            "flip_prob_percent_vs_bottom2save": flip_pb / N_SIMS,
            "flip_prob_rank_vs_bottom2save": flip_rb / N_SIMS,

            "p_match_obs_percent": match_obs_percent / N_SIMS,
            "p_match_obs_rank": match_obs_rank / N_SIMS,
            "p_match_obs_bottom2save": match_obs_bottom2save / N_SIMS,

            # useful diagnostics for later plots
            "controversy_score": float(g["controversy_score"].iloc[0]) if "controversy_score" in g.columns else np.nan,
            "ess": float(g["ess"].iloc[0]) if "ess" in g.columns else np.nan,
        })

    prob_df = pd.DataFrame(prob_rows)
    prob_df.to_csv(os.path.join(args.out, "task2_rule_comparison_probabilistic.csv"), index=False)


    # Task 3 regression
    reg_df=res.dropna(subset=["age","industry"]).copy()
    reg_df["z_judge"]=(reg_df["judge_percent"]-reg_df["judge_percent"].mean())/(reg_df["judge_percent"].std()+1e-9)
    reg_df["z_age"]=(reg_df["age"]-reg_df["age"].mean())/(reg_df["age"].std()+1e-9)
    reg_df["log_fan"]=np.log(reg_df["fan_share_mean"]+1e-6)
    reg_df["industry"]=reg_df["industry"].astype("category")
    model=smf.ols("log_fan ~ z_judge + z_age + C(industry) + C(season)", data=reg_df).fit(cov_type="HC3")
    with open(os.path.join(args.out,"task3_regression_summary.txt"),"w") as f:
        f.write(model.summary().as_text())
    coef=model.params.to_frame("coef")
    coef["se"]=model.bse
    coef["pval"]=model.pvalues
    ind=coef.filter(like="C(industry)", axis=0).copy()
    ind["industry"]=ind.index.str.extract(r"T\.([^]]+)\]")[0]
    ind.sort_values("coef", ascending=False).to_csv(os.path.join(args.out,"task3_industry_effects.csv"), index=False)

    # Task 4 fairness grid (concave fan transform)
    elim_weeks = week_summary[week_summary["n_elim"]>0][["season","week","n_elim"]].copy()
    lams = np.linspace(0.1,0.9,17)
    alphas = [1.0,0.9,0.8,0.7,0.6,0.5]
    grid=[]
    for lam in lams:
        for alpha_fan in alphas:
            upset_j=[]; upset_v=[]; avg_jp=[]; avg_vp=[]; gini_list=[]
            for _, r in elim_weeks.iterrows():
                season=int(r["season"]); week=int(r["week"]); m=int(r["n_elim"])
                g = res[(res["season"]==season) & (res["week"]==week)]
                J=g["judge_total"].values.astype(float)
                x=g["fan_share_mean"].values.astype(float)
                N=len(x)
                pJ=J/(J.sum()+1e-12)
                xt=np.power(x, alpha_fan); xt=xt/xt.sum()
                gini_list.append(gini(xt))
                S=(1-lam)*pJ + lam*xt
                idx=np.argsort(S)[:m]
                jp=rankdata(pJ, method="average")/N
                vp=rankdata(x, method="average")/N
                for i in idx:
                    upset_j.append(jp[i]>0.5)
                    upset_v.append(vp[i]>0.5)
                    avg_jp.append(jp[i])
                    avg_vp.append(vp[i])
            grid.append({
                "lambda": float(lam),
                "alpha_fan": float(alpha_fan),
                "upset_rate_judge": float(np.mean(upset_j)),
                "upset_rate_fan": float(np.mean(upset_v)),
                "avg_elim_judge_percentile": float(np.mean(avg_jp)),
                "avg_elim_fan_percentile": float(np.mean(avg_vp)),
                "avg_vote_gini": float(np.mean(gini_list))
            })
    grid_df=pd.DataFrame(grid)
    grid_df.to_csv(os.path.join(args.out,"task4_fairness_grid.csv"), index=False)

    # Pareto frontier
    vals=grid_df[["avg_elim_judge_percentile","avg_elim_fan_percentile"]].values
    is_pareto=np.ones(len(grid_df),dtype=bool)
    for i in range(len(grid_df)):
        if not is_pareto[i]:
            continue
        dom = np.all(vals<=vals[i],axis=1) & np.any(vals<vals[i],axis=1)
        if np.any(dom):
            is_pareto[i]=False
    pareto=grid_df[is_pareto].sort_values(["avg_elim_judge_percentile","avg_elim_fan_percentile"])
    pareto.to_csv(os.path.join(args.out,"task4_pareto_frontier.csv"), index=False)

    # Simple figs
    elim_cs=week_summary[week_summary["n_elim"]>0]["controversy_score"].values
    plt.figure()
    plt.hist(elim_cs,bins=30)
    plt.xlabel("Controversy score = -log P(elim|prior)")
    plt.ylabel("Count")
    plt.title("Controversy distribution")
    plt.tight_layout()
    plt.savefig(os.path.join(args.out,"fig1_controversy_hist.png"),dpi=200)
    plt.close()

    print("Done. Outputs written to:", args.out)

if __name__=="__main__":
    main()
