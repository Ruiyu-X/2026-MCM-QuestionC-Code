def calc_dynamic_weights(judge_scores, vote_shares):

    judge_std = np.std(judge_scores)

    hhi = np.sum(np.square(vote_shares))

    judge_std_n = judge_std / (judge_std + 5)
    hhi_n = hhi / (hhi + 0.3)

    w_vote = (1 - judge_std_n)

    w_judge = hhi_n


    wj = w_judge
    wv = w_vote

    s = wj + wv
    wj /= s
    wv /= s

    return wj, wv
    def dynamic_bottom2_engine(g):

    g = g.copy()

    g["judge_norm"] = g["judge_total"] / g["judge_total"].sum()
    g["vote_norm"] = g["vote_share_hat"] / g["vote_share_hat"].sum()

    wj, wv = calc_dynamic_weights(
        g["judge_total"].values,
        g["vote_share_hat"].values
    )


    g["final_score"] = (
        wj * g["judge_norm"] +
        wv * g["vote_norm"]
    )

    g = g.sort_values("final_score")


    bottom2 = g.head(2).copy()


    elim = bottom2.sort_values("judge_total").iloc[0]["celebrity_name"]

    return elim, bottom2, wj, wv, g
rows = []

for (s, w), g in df_vote.groupby(["season", "week"]):

    s = int(s)
    w = int(w)

    true_set = true_map.get((s, w), set())
    k = len(true_set)

    if k == 0:
        continue

    pred_elim, bottom2, wj, wv, full = dynamic_bottom2_engine(g)

    hit = int(pred_elim in true_set)

    rows.append({
        "season": s,
        "week": w,
        "true_elim": ",".join(true_set),
        "pred_elim": pred_elim,
        "hit": hit,
        "w_judge": wj,
        "w_vote": wv,
        "bottom2": ",".join(bottom2["celebrity_name"]),
    })


q4_res = pd.DataFrame(rows)


overall_acc = q4_res["hit"].mean()

season_acc = (
    q4_res.groupby("season")["hit"]
    .mean()
    .reset_index(name="elim_acc")
)


def bottom2_cover(row):

    true_set = set(row["true_elim"].split(","))
    bottom2 = set(row["bottom2"].split(","))

    return int(len(true_set & bottom2) > 0)


q4_res["bottom2_hit"] = q4_res.apply(bottom2_cover, axis=1)

bottom2_rate = q4_res["bottom2_hit"].mean()



season_bottom2 = (
    q4_res.groupby("season")["bottom2_hit"]
    .mean()
    .reset_index(name="bottom2_acc")
)
from scipy.stats import spearmanr




def calc_season_spearman(season_id):

    df_s = df_vote[df_vote["season"] == season_id]

    agg = (
        df_s.groupby("celebrity_name")
        .agg({
            "judge_total": "mean",
            "vote_share_hat": "mean",
            "placement": "first"
        })
        .reset_index()
    )

    wj = q4_res[q4_res["season"] == season_id]["w_judge"].mean()
    wv = q4_res[q4_res["season"] == season_id]["w_vote"].mean()

    agg["final_score"] = (
        wj * (agg["judge_total"] / agg["judge_total"].sum()) +
        wv * (agg["vote_share_hat"] / agg["vote_share_hat"].sum())
    )

    agg["pred_rank"] = agg["final_score"].rank(ascending=False)
    agg["true_rank"] = agg["placement"].rank()

    rho, _ = spearmanr(
        agg["pred_rank"],
        agg["true_rank"]
    )

    return rho


spearman_rows = []

for s in sorted(q4_res["season"].unique()):
    rho = calc_season_spearman(s)

    spearman_rows.append({
        "season": s,
        "spearman_final_vs_placement": rho
    })


df_spear = pd.DataFrame(spearman_rows)

mean_rho = df_spear["spearman_final_vs_placement"].mean()


df_q2 = pd.read_csv(
    os.path.join(DATA_DIR, r"C:\Users\xiao\Desktop\Q2_part1_season_level_rank_vs_percent_summary.csv")
)

base_acc_pct  = df_q2["pct_exact_elim"].mean()
base_acc_rank = df_q2["rank_exact_elim"].mean()



def bottom2_cover(row):
   
    true_set = set([x for x in str(row["true_elim"]).split(",") if x != ""])
    bottom2 = set([x for x in str(row["bottom2"]).split(",") if x != ""])

    return int(len(true_set & bottom2) > 0)

if "bottom2_hit" not in q4_res.columns:
    q4_res["bottom2_hit"] = q4_res.apply(bottom2_cover, axis=1)

bottom2_rate = q4_res["bottom2_hit"].mean()


season_eval = (
    season_acc
    .merge(season_bottom2, on="season", how="left")
    .merge(df_spear, on="season", how="left")
    .merge(df_q2[["season", "rank_exact_elim", "pct_exact_elim"]], on="season", how="left")
)



season_acc = (
    q4_res.groupby("season")["hit"]
    .mean()
    .reset_index(name="elim_acc_dynamic")
)

season_bottom2 = (
    q4_res.groupby("season")["bottom2_hit"]
    .mean()
    .reset_index(name="bottom2_acc_dynamic")
)


print("\n【Q4】计算综合排序 vs 最终名次相关性（Spearman）...")

def calc_season_spearman_dynamic(season_id: int):
    df_s = df_vote[df_vote["season"] == season_id].copy()
    if len(df_s) == 0:
        return np.nan

    agg = (
        df_s.groupby("celebrity_name")
        .agg({
            "judge_total": "mean",
            "vote_share_hat": "mean",
            "placement": "first"
        })
        .reset_index()
    )

    wj = q4_res[q4_res["season"] == season_id]["w_judge"].mean()
    wv = q4_res[q4_res["season"] == season_id]["w_vote"].mean()

    jt_sum = agg["judge_total"].sum()
    vs_sum = agg["vote_share_hat"].sum()

    jt_share = agg["judge_total"] / jt_sum if jt_sum > 0 else 0.0
    vs_share = agg["vote_share_hat"] / vs_sum if vs_sum > 0 else 0.0

    agg["final_score"] = wj * jt_share + wv * vs_share

    agg["pred_rank"] = agg["final_score"].rank(ascending=False, method="average")
    agg["true_rank"] = agg["placement"].rank(ascending=True, method="average")  # placement: 1最好

    rho, _ = spearmanr(agg["pred_rank"], agg["true_rank"])
    return rho

spearman_rows = []
for s in sorted(q4_res["season"].unique()):
    rho = calc_season_spearman_dynamic(int(s))
    spearman_rows.append({
        "season": int(s),
        "spearman_dynamic_final_vs_placement": rho
    })

df_spear = pd.DataFrame(spearman_rows)
mean_rho = df_spear["spearman_dynamic_final_vs_placement"].mean()

print("动态+Bottom2 机制 平均 Spearman 相关系数：", round(mean_rho, 4))
print("\n【Q4】稳定性测试（票数±3%扰动）...")

def perturb_test(g, n=30, eps=0.03):

    base_elim, _, _, _, _ = dynamic_bottom2_engine(g)

    cnt = 0

    for _ in range(n):

        gg = g.copy()

        noise = np.random.normal(0, eps, len(gg))
        gg["vote_share_hat"] = gg["vote_share_hat"] * (1 + noise)
        gg["vote_share_hat"] = np.clip(gg["vote_share_hat"], 1e-6, None)

        gg["vote_share_hat"] /= gg["vote_share_hat"].sum()

        e, _, _, _, _ = dynamic_bottom2_engine(gg)

        if e == base_elim:
            cnt += 1

    return cnt / n


stabs = []

for (s,w), g in df_vote.groupby(["season","week"]):

    if len(true_map.get((int(s),int(w)),[]))==0:
        continue

    stabs.append(perturb_test(g))

stab_mean = np.mean(stabs)
