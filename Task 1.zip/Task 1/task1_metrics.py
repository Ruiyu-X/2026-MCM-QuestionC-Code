"""
Run:
  python task1_metrics.py --fan_csv "task1_fan_vote_estimates.csv" --week_csv "task1_week_summary.csv" --out "task1_week_metrics.csv"
"""

import argparse
from pathlib import Path
import numpy as np
import pandas as pd


def sigmoid(z: np.ndarray) -> np.ndarray:
    return 1.0 / (1.0 + np.exp(-z))


def overlap_ratio(l1: float, u1: float, l2: float, u2: float) -> float:
    """Intersection length / Union length for two 1D intervals."""
    inter = max(0.0, min(u1, u2) - max(l1, l2))
    union = max(0.0, max(u1, u2) - min(l1, l2))
    return 0.0 if union <= 0 else inter / union


def rank_avg_desc(arr: np.ndarray) -> np.ndarray:
    """Rank values so that higher value => rank 1 (best)."""
    return pd.Series(-arr).rank(method="average").to_numpy()


def compute_week_metrics(
    g: pd.DataFrame,
    lam: float,
    use_col: str,
    risk_scale_mode: str,
    tau_percent: float,
    tau_rank: float,
) -> dict | None:
    """
    g: one (season, week) group from task1_fan_vote_estimates.csv
    """
    m = int(g["elim_this_week"].sum())  # number eliminated that week
    n = len(g)
    if m <= 0 or n <= 0:
        return None

    scheme = str(g["scheme_assumed"].iloc[0])  # "percent" / "rank" / "rank+save"
    names = g["celebrity_name"].tolist()

    J = g["judge_total"].to_numpy(float)
    jp = g["judge_percent"].to_numpy(float)
    x = g[use_col].to_numpy(float)

    actual_set = set(g.loc[g["elim_this_week"] == 1, "celebrity_name"].tolist())

    # -------- compute predicted elimination, margin, and risk weights --------
    margin = None
    overlap_certainty = None

    if scheme == "percent":
        # lower S = worse
        S = (1.0 - lam) * jp + lam * x
        order = np.argsort(S)  # ascending, worst first

        pred_idx = order[:m]
        bottom2_idx = order[: min(2, n)]

        if n > m:
            # margin between last eliminated and first safe
            margin = float(S[order[m]] - S[order[m - 1]])

        # risk weights for "weighted jaccard" (soft IoU)
        thresh = float(S[order[m - 1]])  # cutline score (m-th worst)
        if risk_scale_mode == "margin" and (margin is not None):
            scale = float(max(margin, 1e-6))
        else:
            scale = float(np.std(S) + 1e-9)
        # risk ~ 1 if far worse than cutline; ~0 if safely above it
        risk = sigmoid((thresh - S) / scale)

        # overlap certainty: compare boundary eliminated vs boundary safe
        if n > m:
            elim_mask = (g["elim_this_week"].to_numpy(int) == 1)
            safe_mask = ~elim_mask

            elim_candidates = np.where(elim_mask)[0]
            safe_candidates = np.where(safe_mask)[0]

            # boundary eliminated: eliminated with highest S (closest to safe)
            be = elim_candidates[np.argmax(S[elim_candidates])]
            # boundary safe: safe with lowest S (closest to eliminated)
            bs = safe_candidates[np.argmin(S[safe_candidates])]

            l1, u1 = float(g.iloc[be]["fan_share_ci_low"]), float(g.iloc[be]["fan_share_ci_high"])
            l2, u2 = float(g.iloc[bs]["fan_share_ci_low"]), float(g.iloc[bs]["fan_share_ci_high"])
            overlap_certainty = 1.0 - overlap_ratio(l1, u1, l2, u2)

    else:
        # rank / rank+save
        # higher combined rank sum = worse
        rJ = rank_avg_desc(J)
        rV = rank_avg_desc(x)
        R = rJ + rV
        order = np.argsort(-R)  # descending, worst first

        # rank+save: bottom2 then judges eliminate the one with LOWER judge_percent
        if scheme == "rank+save" and m == 1 and n >= 2:
            bottom2 = order[:2]
            i, j = bottom2
            e = i if jp[i] < jp[j] else j
            pred_idx = np.array([e], dtype=int)
        else:
            pred_idx = order[:m]

        bottom2_idx = order[: min(2, n)]

        if n > m:
            margin = float(R[order[m - 1]] - R[order[m]])  # separation at cutline

        thresh = float(R[order[m - 1]])
        if risk_scale_mode == "margin" and (margin is not None):
            scale = float(max(margin, 1e-6))
        else:
            scale = float(np.std(R) + 1e-9)
        risk = sigmoid((R - thresh) / scale)  # worse than cutline => risk~1

        if n > m:
            elim_mask = (g["elim_this_week"].to_numpy(int) == 1)
            safe_mask = ~elim_mask

            elim_candidates = np.where(elim_mask)[0]
            safe_candidates = np.where(safe_mask)[0]

            # boundary eliminated: eliminated with LOWEST R (closest to safe)
            be = elim_candidates[np.argmin(R[elim_candidates])]
            # boundary safe: safe with HIGHEST R (closest to eliminated)
            bs = safe_candidates[np.argmax(R[safe_candidates])]

            l1, u1 = float(g.iloc[be]["fan_share_ci_low"]), float(g.iloc[be]["fan_share_ci_high"])
            l2, u2 = float(g.iloc[bs]["fan_share_ci_low"]), float(g.iloc[bs]["fan_share_ci_high"])
            overlap_certainty = 1.0 - overlap_ratio(l1, u1, l2, u2)

    pred_set = set([names[i] for i in pred_idx])
    bottom2_set = set([names[i] for i in bottom2_idx])

    # -------- metrics you asked for --------
    # 1) match rate (per week)
    match = 1.0 if pred_set == actual_set else 0.0

    # 2) bottom-2 hit rate:
    # - if single elimination: 1 if eliminated is in predicted bottom2
    # - if multi elimination: we also report recall in bottom2
    bottom2_hit_single = np.nan
    if m == 1:
        bottom2_hit_single = 1.0 if len(actual_set & bottom2_set) == 1 else 0.0
    bottom2_recall = (len(actual_set & bottom2_set) / m) if m > 0 else np.nan

    # 3) Jaccard
    inter = len(actual_set & pred_set)
    union = len(actual_set | pred_set)
    jaccard = inter / union if union else np.nan

    # 4) Weighted Jaccard (soft IoU):
    # treat "risk" as fuzzy set membership; actual elimination as crisp set
    w_true = (g["elim_this_week"].to_numpy(int) == 1).astype(float)
    weighted_jaccard = float(np.sum(np.minimum(risk, w_true)) / np.sum(np.maximum(risk, w_true)))

    # 5) Margin Certainty in [0,1]
    if margin is None:
        margin_certainty = np.nan
    else:
        tau = tau_percent if scheme == "percent" else tau_rank
        margin_certainty = float(margin / (margin + tau)) if margin >= 0 else 0.0

    return {
        "scheme_assumed": scheme,
        "n_active": int(n),
        "n_elim": int(m),

        "match": match,
        "bottom2_hit_single": bottom2_hit_single,
        "bottom2_recall": float(bottom2_recall),

        "jaccard": float(jaccard),
        "weighted_jaccard": float(weighted_jaccard),

        "margin": margin,
        "margin_certainty": margin_certainty,

        "overlap_certainty": overlap_certainty,

        "actual_elim": ";".join(sorted(actual_set)),
        "pred_elim": ";".join(sorted(pred_set)),
        "pred_bottom2": ";".join(sorted(bottom2_set)),
    }


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--fan_csv", default="task1_fan_vote_estimates.csv")
    ap.add_argument("--week_csv", default="task1_week_summary.csv")  # 可选：用于合并周级信息
    ap.add_argument("--use", default="fan_share_point",
                    choices=["fan_share_point", "fan_share_mean", "fan_share_map"])
    ap.add_argument("--lam", type=float, default=0.5, help="percent 规则下粉丝权重 λ")
    ap.add_argument("--risk_scale", default="std", choices=["std", "margin"],
                    help="weighted_jaccard 风险权重的尺度：std 更平滑；margin 更贴近淘汰线")
    ap.add_argument("--tau_percent", type=float, default=0.01, help="percent margin certainty 的 τ")
    ap.add_argument("--tau_rank", type=float, default=1.0, help="rank margin certainty 的 τ")
    ap.add_argument("--out", default="task1_week_metrics.csv")
    args = ap.parse_args()

    fan = pd.read_csv(args.fan_csv)
    # week_summary 不是必须，但合并后更方便查看 ess/controversy
    week = None
    if Path(args.week_csv).exists():
        week = pd.read_csv(args.week_csv)

    rows = []
    for (season, weeknum), g in fan.groupby(["season", "week"]):
        r = compute_week_metrics(
            g=g,
            lam=args.lam,
            use_col=args.use,
            risk_scale_mode=args.risk_scale,
            tau_percent=args.tau_percent,
            tau_rank=args.tau_rank,
        )
        if r is None:
            continue
        r["season"] = int(season)
        r["week"] = int(weeknum)
        rows.append(r)

    out = pd.DataFrame(rows).sort_values(["season", "week"]).reset_index(drop=True)

    # optional merge with week summary (ess/controversy)
    if week is not None:
        out = out.merge(
            week[["season", "week", "predictive_prob", "log_predictive_prob", "ess", "controversy_score"]],
            on=["season", "week"],
            how="left",
        )

    out.to_csv(args.out, index=False, encoding="utf-8-sig")

    # -------- overall summary prints --------
    valid = out[out["n_elim"] > 0].copy()
    print(f"Saved: {args.out}")
    print("\n=== Overall (weeks with elimination) ===")
    print(f"Match rate: {valid['match'].mean():.4f}")
    print(f"Avg Jaccard: {valid['jaccard'].mean():.4f}")
    print(f"Avg Weighted Jaccard: {valid['weighted_jaccard'].mean():.4f}")

    single = valid[valid["n_elim"] == 1]
    if len(single) > 0:
        print(f"Bottom-2 hit rate (single-elim weeks): {single['bottom2_hit_single'].mean():.4f}")
    print(f"Bottom-2 recall (all elim weeks): {valid['bottom2_recall'].mean():.4f}")

    print(f"Avg margin certainty: {valid['margin_certainty'].mean():.4f}")
    print(f"Avg overlap certainty: {valid['overlap_certainty'].mean():.4f}")

    print("\n=== Most uncertain by margin certainty (bottom 10) ===")
    cols = [c for c in ["season", "week", "scheme_assumed", "n_active", "n_elim",
                       "margin", "margin_certainty", "overlap_certainty",
                       "match", "jaccard"] if c in out.columns]
    print(out.sort_values("margin_certainty", ascending=True).head(10)[cols].to_string(index=False))


if __name__ == "__main__":
    main()