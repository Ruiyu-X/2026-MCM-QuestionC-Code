"""
Run:
  python figs.py --csv task1_week_metrics_plus.csv --out task1_figs
"""

import argparse
import math
from pathlib import Path

import numpy as np
import pandas as pd
import matplotlib.pyplot as plt
from matplotlib.colors import LinearSegmentedColormap

PALETTE = {
    "teal":   "#59C7B8",
    "green":  "#9AD66D",
    "orange": "#F7B556",
    "blue":   "#86B6FF",
    "pink":   "#F5A3B8",
    "gray":   "#6B7280",
    "text":   "#374151",
}

def wilson_ci(k, n, z=1.96):
    if n == 0:
        return (np.nan, np.nan)
    p = k / n
    denom = 1 + z**2 / n
    center = (p + z**2 / (2*n)) / denom
    half = z * math.sqrt((p*(1-p) + z**2/(4*n)) / n) / denom
    return center - half, center + half

def add_thresholds_with_labels(thresholds, labels, y=0.06):
    for t, lab in zip(thresholds, labels):
        plt.axvline(t, color=PALETTE["gray"], linewidth=1.2, alpha=0.55)
        plt.text(
            t, y, lab,
            rotation=90, ha="right", va="bottom",
            fontsize=10, color=PALETTE["gray"], alpha=0.85
        )

def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--csv", required=True, help="task1_week_metrics_plus.csv")
    ap.add_argument("--out", default="task1_figs_pretty_v3")
    args = ap.parse_args()

    df = pd.read_csv(args.csv)
    out_dir = Path(args.out)
    out_dir.mkdir(parents=True, exist_ok=True)

    plt.style.use("seaborn-v0_8-whitegrid")
    plt.rcParams.update({
        "figure.dpi": 220,
        "savefig.dpi": 220,
        "font.size": 12,
        "axes.titlesize": 16,
        "axes.labelsize": 13,
        "legend.fontsize": 11,
        "xtick.labelsize": 12,
        "ytick.labelsize": 12,
        "axes.spines.top": False,
        "axes.spines.right": False,
        "grid.alpha": 0.22,
        "grid.linewidth": 0.8,
        "text.color": PALETTE["text"],
        "axes.labelcolor": PALETTE["text"],
        "xtick.color": PALETTE["text"],
        "ytick.color": PALETTE["text"],
    })

    # Fig 1
    match_k = int(df["match"].sum())
    match_n = int(len(df))
    match = match_k / match_n
    match_ci = wilson_ci(match_k, match_n)

    single = df[df["n_elim"] == 1].copy()
    b2 = single["bottom2_hit_single"].dropna()
    b2_k = int(b2.sum())
    b2_n = int(len(b2))
    bottom2 = b2_k / b2_n
    bottom2_ci = wilson_ci(b2_k, b2_n)

    avg_j = float(df["jaccard"].mean())
    avg_certflip = float(df["certainty_flip"].mean())
    avg_pmatch = float(df["p_match_actual"].mean())

    labels = ["Match", "Bottom-2 hit", "Jaccard", "Certainty (1−Flip)", "p_match_actual"]
    vals = [match, bottom2, avg_j, avg_certflip, avg_pmatch]
    colors = [PALETTE["teal"], PALETTE["green"], PALETTE["orange"], PALETTE["blue"], PALETTE["pink"]]

    upper_bounds = [match_ci[1], bottom2_ci[1], avg_j, avg_certflip, avg_pmatch]
    label_y = [ub + 0.035 for ub in upper_bounds]

    x = np.arange(len(labels))
    plt.figure(figsize=(9.2, 5.2))
    plt.bar(x, vals, color=colors, edgecolor="white", linewidth=1.0)

    plt.errorbar([x[0], x[1]], [vals[0], vals[1]],
                 yerr=[[vals[0]-match_ci[0], vals[1]-bottom2_ci[0]],
                       [match_ci[1]-vals[0], bottom2_ci[1]-vals[1]]],
                 fmt='none', ecolor=PALETTE["gray"], elinewidth=1.8, capsize=7)

    plt.ylim(0, 1.12)
    plt.xticks(x, labels)
    plt.ylabel("Score (0–1)")
    plt.title("Global Consistency & Certainty Summary")

    for xi, v, y in zip(x, vals, label_y):
        plt.text(xi, y, f"{v:.2f}", ha="center", va="bottom", fontsize=12)

    plt.tight_layout()
    plt.savefig(out_dir / "fig1_global_summary_pastel_v2.png")
    plt.close()

    # Fig 2
    flip = df["flip_prob"].dropna().to_numpy()
    flip_sorted = np.sort(flip)
    ecdf = np.arange(1, len(flip_sorted)+1) / len(flip_sorted)

    step = max(1, len(flip_sorted)//250)
    xs = flip_sorted[::step]
    ys = ecdf[::step]
    xn = (xs - xs.min()) / (xs.max() - xs.min() + 1e-12)

    plt.figure(figsize=(8.2, 5.0))
    plt.plot(flip_sorted, ecdf, color=PALETTE["teal"], linewidth=2.4, alpha=0.55)
    plt.scatter(xs, ys, c=xn, cmap="GnBu", s=28, edgecolors="white", linewidth=0.4, alpha=0.95)

    add_thresholds_with_labels([0.1, 0.5, 0.9], ["Low fragility", "Medium", "High fragility"], y=0.04)

    plt.xlim(0, 1)
    plt.ylim(0, 1)
    plt.xlabel("Flip probability")
    plt.ylabel("Empirical CDF")
    plt.title("Decision Uncertainty: Flip Probability (ECDF)")
    plt.tight_layout()
    plt.savefig(out_dir / "fig2_flip_ecdf_gradient_v2.png")
    plt.close()

    # Fig 3
    pm = df["p_match_actual"].dropna().to_numpy()
    pm_sorted = np.sort(pm)
    ecdf2 = np.arange(1, len(pm_sorted)+1) / len(pm_sorted)

    step2 = max(1, len(pm_sorted)//250)
    xs2 = pm_sorted[::step2]
    ys2 = ecdf2[::step2]
    xn2 = (xs2 - xs2.min()) / (xs2.max() - xs2.min() + 1e-12)

    plt.figure(figsize=(8.2, 5.0))
    plt.plot(pm_sorted, ecdf2, color=PALETTE["green"], linewidth=2.4, alpha=0.55)
    plt.scatter(xs2, ys2, c=xn2, cmap="YlGn", s=28, edgecolors="white", linewidth=0.4, alpha=0.95)

    add_thresholds_with_labels([0.1, 0.5, 0.9], ["Low agreement", "Medium", "High agreement"], y=0.04)

    plt.xlim(0, 1)
    plt.ylim(0, 1)
    plt.xlabel("p_match_actual (probabilistic agreement)")
    plt.ylabel("Empirical CDF")
    plt.title("Probabilistic Consistency: p_match_actual (ECDF)")
    plt.tight_layout()
    plt.savefig(out_dir / "fig3_pmatch_ecdf_gradient_v2.png")
    plt.close()

    # Fig 4
    plt.figure(figsize=(8.2, 5.4))
    mask_match = df["match"] == 1
    plt.scatter(df.loc[mask_match, "flip_prob"], df.loc[mask_match, "p_match_actual"],
                s=48, alpha=0.75, color=PALETTE["teal"], label="Match=1")
    plt.scatter(df.loc[~mask_match, "flip_prob"], df.loc[~mask_match, "p_match_actual"],
                s=48, alpha=0.72, color="#F06A6A", label="Match=0")
    plt.axvline(0.5, color=PALETTE["gray"], linewidth=1.2, alpha=0.55)
    plt.axhline(0.5, color=PALETTE["gray"], linewidth=1.2, alpha=0.55)
    plt.xlim(0, 1)
    plt.ylim(0, 1)
    plt.xlabel("Flip probability (fragility)")
    plt.ylabel("p_match_actual (probabilistic agreement)")
    plt.title("Fragility vs Probabilistic Agreement")
    plt.legend(frameon=False, loc="upper right")
    plt.tight_layout()
    plt.savefig(out_dir / "fig4_flip_vs_pmatch.png")
    plt.close()

    # Fig 5
    # Binning
    bins = np.linspace(0, 1, 11)
    pm_bin = pd.cut(df["p_match_actual"], bins=bins, include_lowest=True)
    cal = df.groupby(pm_bin, observed=True).agg(
        count=("match", "size"),
        avg_p=("p_match_actual", "mean"),
        emp=("match", "mean"),
    ).reset_index()
    cal = cal[np.isfinite(cal["avg_p"]) & np.isfinite(cal["emp"])].copy()

    cnt = cal["count"].to_numpy(float)
    cn = (cnt - cnt.min()) / (cnt.max() - cnt.min() + 1e-12)
    sizes = 70 + 260 * cn  # size encodes support

    support_cmap = LinearSegmentedColormap.from_list(
        "support_pastel_visible",
        ["#BFE9FF", "#86D2F7", "#5CBFEA"]  # light->mid (still pastel)
    )

    fig = plt.figure(figsize=(8.4, 5.6))
    ax = plt.gca()

    ax.plot(cal["avg_p"], cal["emp"], linewidth=2.8, color=PALETTE["blue"], alpha=0.70, zorder=2)
    sc = ax.scatter(
        cal["avg_p"], cal["emp"],
        c=cn, cmap=support_cmap, s=sizes,
        edgecolors="white", linewidth=0.9, alpha=0.98, zorder=3
    )
    ax.plot([0, 1], [0, 1], linestyle="--", linewidth=2.0, color=PALETTE["gray"], alpha=0.75, zorder=1)

    ax.set_xlim(0, 1)
    ax.set_ylim(-0.02, 1.05)  # avoid top clipping illusion
    ax.set_xlabel("Average p_match_actual")
    ax.set_ylabel("Empirical match rate")
    ax.set_title("Calibration of p_match_actual", pad=14)

    for _, r in cal.iterrows():
        x0, y0, n = float(r["avg_p"]), float(r["emp"]), int(r["count"])
        y_text = min(1.02, y0 + 0.05)
        ax.text(x0, y_text, f"n={n}", ha="center", va="bottom",
                fontsize=10, color=PALETTE["text"], alpha=0.9)

    cbar = plt.colorbar(sc, ax=ax, fraction=0.035, pad=0.02)
    cbar.set_label("Bin support (relative)", rotation=90, labelpad=10)
    cbar.outline.set_visible(False)

    plt.tight_layout()
    plt.savefig(out_dir / "fig5_calibration_clean_visible.png")
    plt.close()

    # Fig 6
    plt.figure(figsize=(8.2, 5.2))
    schemes = list(df["scheme_assumed"].dropna().unique())
    data = [df.loc[df["scheme_assumed"] == s, "flip_prob"].dropna().to_numpy() for s in schemes]

    bp = plt.boxplot(data, labels=schemes, showfliers=False, patch_artist=True,
                     medianprops=dict(color="white", linewidth=2.0),
                     whiskerprops=dict(color=PALETTE["gray"], linewidth=1.2),
                     capprops=dict(color=PALETTE["gray"], linewidth=1.2),
                     boxprops=dict(edgecolor="white", linewidth=1.0))

    box_colors = [PALETTE["teal"], PALETTE["green"], PALETTE["orange"], PALETTE["blue"], "#F06A6A"]
    for patch, c in zip(bp["boxes"], box_colors):
        patch.set_facecolor(c)
        patch.set_alpha(0.78)

    rng = np.random.default_rng(0)
    for i, arr in enumerate(data, start=1):
        if len(arr) == 0:
            continue
        xsj = rng.normal(i, 0.05, size=len(arr))
        plt.scatter(xsj, arr, s=10, alpha=0.14, color=PALETTE["text"])

    plt.ylabel("Flip probability")
    plt.title("Flip Probability by Rule Scheme")
    plt.ylim(0, 1)
    plt.tight_layout()
    plt.savefig(out_dir / "fig6_flip_by_scheme.png")
    plt.close()

    print("Saved figures to:", out_dir.resolve())
    print("Updated Fig5 saved as:", (out_dir / "fig5_calibration_clean_visible.png").resolve())

if __name__ == "__main__":
    main()