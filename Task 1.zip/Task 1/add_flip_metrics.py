"""
Run:
  python add_flip_metrics.py --fan_csv "task1_fan_vote_estimates.csv" --week_metrics_csv "task1_week_metrics.csv" --out "task1_week_metrics_plus.csv" --samples 3000 --seed 0 --use fan_share_point --lam 0.5
"""

import argparse
import numpy as np
import pandas as pd


def predict_elim_set_percent(judge_percent, fan_share, lam, m):
    # composite score (lower is worse)
    S = (1.0 - lam) * judge_percent + lam * fan_share
    order = np.argsort(S)  # ascending
    idx = order[:m]
    return tuple(sorted(idx))


def predict_elim_set_rank(judge_total, fan_share, judge_percent, m, scheme):
    # ranks: higher value => rank 1 (best). We'll use argsort twice (ties rare after sampling).
    # rJ fixed, rV depends on fan_share.
    rJ = (-judge_total).argsort().argsort() + 1
    rV = (-fan_share).argsort().argsort() + 1
    R = rJ + rV  # larger = worse
    order = np.argsort(-R)  # descending, worst first

    if scheme == "rank+save" and m == 1 and len(fan_share) >= 2:
        bottom2 = order[:2]
        i, j = bottom2
        e = i if judge_percent[i] < judge_percent[j] else j  # simplified judge save
        return (e,)
    else:
        idx = order[:m]
        return tuple(sorted(idx))


def sample_fan_shares(mean, sd, ci_low, ci_high, n_samples, rng):
    """
    Sample nonnegative shares then renormalize to sum=1 per sample.
    sd may be missing; if so, approximate from 95% CI width.
    """
    sd2 = sd.copy()
    # approximate sd from CI if needed: 95% CI width ~ 3.92 * sd
    need = ~np.isfinite(sd2) | (sd2 <= 0)
    approx_sd = (ci_high - ci_low) / 3.92
    sd2[need] = approx_sd[need]

    # still bad? give tiny noise to avoid all-zero
    sd2[~np.isfinite(sd2) | (sd2 <= 0)] = 1e-6

    X = rng.normal(loc=mean[None, :], scale=sd2[None, :], size=(n_samples, len(mean)))
    X = np.clip(X, 0.0, None)
    row_sum = X.sum(axis=1, keepdims=True)
    # if a row becomes all zeros, fallback to mean then normalize
    bad = (row_sum[:, 0] <= 0)
    if bad.any():
        X[bad, :] = np.clip(mean, 0.0, None)
        row_sum = X.sum(axis=1, keepdims=True)
    X = X / (row_sum + 1e-12)
    return X


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--fan_csv", required=True, help="task1_fan_vote_estimates.csv")
    ap.add_argument("--week_metrics_csv", required=True, help="task1_week_metrics.csv")
    ap.add_argument("--out", default="task1_week_metrics_plus.csv")
    ap.add_argument("--use", default="fan_share_point",
                    choices=["fan_share_point", "fan_share_mean", "fan_share_map"],
                    help="baseline point estimate used to define 'flip'")
    ap.add_argument("--lam", type=float, default=0.5, help="lambda in percent rule")
    ap.add_argument("--samples", type=int, default=2000, help="MC samples per week")
    ap.add_argument("--seed", type=int, default=0)
    args = ap.parse_args()

    fan = pd.read_csv(args.fan_csv)
    wk = pd.read_csv(args.week_metrics_csv)

    rng = np.random.default_rng(args.seed)

    rows = []
    for (season, week), g in fan.groupby(["season", "week"]):
        m = int(g["elim_this_week"].sum())
        if m <= 0:
            continue

        scheme = str(g["scheme_assumed"].iloc[0])
        names = g["celebrity_name"].tolist()

        judge_total = g["judge_total"].to_numpy(float)
        judge_percent = g["judge_percent"].to_numpy(float)

        # baseline prediction uses chosen point estimate
        base_share = g[args.use].to_numpy(float)

        if scheme == "percent":
            base_pred = predict_elim_set_percent(judge_percent, base_share, args.lam, m)
        else:
            base_pred = predict_elim_set_rank(judge_total, base_share, judge_percent, m, scheme)

        # actual elimination set index-tuple
        actual_idx = tuple(sorted(np.where(g["elim_this_week"].to_numpy(int) == 1)[0]))

        # sampling distribution (use mean + sd or CI)
        mean = g["fan_share_mean"].to_numpy(float) if "fan_share_mean" in g.columns else g[args.use].to_numpy(float)
        sd = g["fan_share_sd"].to_numpy(float) if "fan_share_sd" in g.columns else np.full_like(mean, np.nan)
        ci_low = g["fan_share_ci_low"].to_numpy(float)
        ci_high = g["fan_share_ci_high"].to_numpy(float)

        Xs = sample_fan_shares(mean, sd, ci_low, ci_high, args.samples, rng)

        flip = 0
        match_actual = 0

        for t in range(args.samples):
            share = Xs[t]
            if scheme == "percent":
                pred = predict_elim_set_percent(judge_percent, share, args.lam, m)
            else:
                pred = predict_elim_set_rank(judge_total, share, judge_percent, m, scheme)

            if pred != base_pred:
                flip += 1
            if pred == actual_idx:
                match_actual += 1

        flip_prob = flip / args.samples
        p_match_actual = match_actual / args.samples

        # estimation-level: mean relative CI width this week
        ci_width = (ci_high - ci_low)
        rel_ci_width = ci_width / (mean + 1e-12)
        mean_rel_ci_width = float(np.nanmean(rel_ci_width))

        rows.append({
            "season": int(season),
            "week": int(week),
            "flip_prob": float(flip_prob),
            "certainty_flip": float(1.0 - flip_prob),
            "p_match_actual": float(p_match_actual),
            "mean_rel_ci_width": mean_rel_ci_width,
        })

    add = pd.DataFrame(rows)
    out = wk.merge(add, on=["season", "week"], how="left")

    out.to_csv(args.out, index=False, encoding="utf-8-sig")
    print(f"Saved: {args.out}")

    # quick summary
    valid = out[out["n_elim"] > 0].copy()
    print("\n=== Summary ===")
    print("Avg flip_prob:", np.nanmean(valid["flip_prob"]))
    print("Avg certainty_flip:", np.nanmean(valid["certainty_flip"]))
    print("Avg p_match_actual:", np.nanmean(valid["p_match_actual"]))
    print("Avg mean_rel_ci_width:", np.nanmean(valid["mean_rel_ci_width"]))

    print("\nTop 10 most uncertain weeks (highest flip_prob):")
    cols = [c for c in ["season","week","scheme_assumed","n_active","n_elim","flip_prob","certainty_flip",
                       "match","bottom2_hit_single","jaccard","mean_rel_ci_width"] if c in valid.columns]
    print(valid.sort_values("flip_prob", ascending=False).head(10)[cols].to_string(index=False))


if __name__ == "__main__":
    main()