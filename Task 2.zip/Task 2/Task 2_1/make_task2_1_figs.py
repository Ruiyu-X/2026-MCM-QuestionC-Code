"""
Make Task2-1 figures from:
  - task2_1_metrics_by_event.csv
  - task2_1_summary_by_season.csv

Auto-detect the flip-probability column (e.g., flip_prob_percent_vs_rank).
"""

import os
import numpy as np
import pandas as pd
import matplotlib.pyplot as plt
from matplotlib.colors import LinearSegmentedColormap

EVENTS_CSV = "task2_1_metrics_by_event.csv"
SEASON_CSV = "task2_1_summary_by_season.csv"
OUT_DIR = "task2_1_figs"

def set_pretty_style():
    plt.rcParams.update({
        "figure.dpi": 160,
        "savefig.dpi": 320,
        "font.size": 12,
        "axes.titlesize": 18,
        "axes.labelsize": 13,
        "xtick.labelsize": 11,
        "ytick.labelsize": 11,
        "axes.grid": True,
        "grid.alpha": 0.25,
        "grid.linestyle": "-",
        "axes.spines.top": False,
        "axes.spines.right": False,
    })

def pastel_cmap(hex1, hex2, name="custom"):
    return LinearSegmentedColormap.from_list(name, [hex1, hex2])

def save(fig, out_dir, name):
    os.makedirs(out_dir, exist_ok=True)
    path = os.path.join(out_dir, name)
    fig.savefig(path, bbox_inches="tight")
    plt.close(fig)
    print("saved:", path)

def pick_flip_col(df: pd.DataFrame) -> str:
    # Prefer exact names, otherwise first column containing "flip_prob"
    for c in df.columns:
        if c.lower() in {"flip_prob", "flip_probability"}:
            return c
    for c in df.columns:
        if "flip_prob" in c.lower():
            return c
    raise ValueError(f"Could not find flip probability column. Columns={list(df.columns)}")

def main():
    set_pretty_style()
    events = pd.read_csv(EVENTS_CSV)
    seasons = pd.read_csv(SEASON_CSV)

    flip_col = pick_flip_col(events)
    disagree_col = "disagree" if "disagree" in events.columns else next((c for c in events.columns if c.lower()=="disagree"), None)
    if disagree_col is None:
        raise ValueError(f"Could not find disagree column. Columns={list(events.columns)}")

    # Ensure numeric
    events[flip_col] = pd.to_numeric(events[flip_col], errors="coerce")
    events[disagree_col] = pd.to_numeric(events[disagree_col], errors="coerce")
    seasons["disagree_rate"] = pd.to_numeric(seasons["disagree_rate"], errors="coerce")
    seasons["avg_flip_prob"] = pd.to_numeric(seasons["avg_flip_prob"], errors="coerce")

    # Fig 1: Disagreement rate across seasons
    fig, ax = plt.subplots(figsize=(10.5, 4.6))
    x = seasons["season"].values
    y = seasons["disagree_rate"].values
    cmap = pastel_cmap("#bfead0", "#3aa6c9", "mint_to_teal")
    colors = cmap(np.linspace(0.15, 0.95, len(x)))
    ax.bar(x, y, color=colors, edgecolor=(0,0,0,0.08), linewidth=0.8)
    ax.set_title("Rule Disagreement Across Seasons")
    ax.set_xlabel("Season")
    ax.set_ylabel("Disagreement rate (Percent vs Rank)")
    ax.set_ylim(0, max(0.05, np.nanmax(y) * 1.25))
    save(fig, OUT_DIR, "fig1_disagreement_rate_by_season.png")

    # Fig 2: Fan-Lean Index across seasons
    fig, ax = plt.subplots(figsize=(10.5, 4.6))
    x = seasons["season"].values
    y1 = seasons["FLI_percent"].values
    y2 = seasons["FLI_rank"].values
    ax.axhline(0, color=(0,0,0,0.35), lw=1.5, ls="--")
    ax.plot(x, y1, marker="o", lw=2.8, color="#ff8b6b", alpha=0.95, label="Percent rule")
    ax.plot(x, y2, marker="o", lw=2.8, color="#f2c48a", alpha=0.95, label="Rank rule")
    ax.set_title("Fan-Lean Index Across Seasons")
    ax.set_xlabel("Season")
    ax.set_ylabel("Fan-Lean Index (FA − JA)")
    ax.legend(frameon=False, ncols=2, loc="upper right")
    save(fig, OUT_DIR, "fig2_fli_trends_by_season.png")

    # Fig 3: Event-level FLI distribution (discrete)
    fig, ax = plt.subplots(figsize=(8.6, 4.8))
    bins = [-1, 0, 1]
    labels = ["−1 (Judge-lean)", "0 (Tie)", "+1 (Fan-lean)"]

    def proportions(series):
        s = pd.to_numeric(series, errors="coerce").dropna().astype(int)
        return np.array([(s == b).mean() if len(s) else np.nan for b in bins])

    p_pct = proportions(events["FLI_percent"])
    p_rnk = proportions(events["FLI_rank"])

    idx = np.arange(len(bins))
    w = 0.36
    ax.bar(idx - w/2, p_pct, width=w, color="#ff8b6b", alpha=0.85, label="Percent rule")
    ax.bar(idx + w/2, p_rnk, width=w, color="#f2c48a", alpha=0.85, label="Rank rule")
    ax.set_xticks(idx)
    ax.set_xticklabels(labels)
    ax.set_ylim(0, max(np.nanmax(p_pct), np.nanmax(p_rnk)) * 1.25)
    ax.set_ylabel("Proportion of events")
    ax.set_title("Fan-Lean Index Distribution (Event level)")
    ax.legend(frameon=False, ncols=2, loc="upper right")
    save(fig, OUT_DIR, "fig3_fli_distribution.png")

    # Fig 4: Fan-win rate within disagreement weeks
    fig, ax = plt.subplots(figsize=(10.5, 4.6))
    x = seasons["season"].values
    fanwin = seasons["percent_more_fan_rate_in_disagree"].values
    mask = ~np.isnan(fanwin)
    ax.axhline(0.5, color=(0,0,0,0.35), lw=1.5, ls="--")
    ax.plot(x[mask], fanwin[mask], marker="o", lw=3.0, color="#7fb6ff", alpha=0.95)
    ax.scatter(x[~mask], np.full(np.sum(~mask), 0.5), s=30, color=(0,0,0,0.15), label="No disagreement events")
    ax.set_ylim(0, 1.02)
    ax.set_title("Which Rule Matches Fan Elimination More Often?")
    ax.set_xlabel("Season")
    ax.set_ylabel("Fan-win rate (within disagreement weeks)")
    ax.legend(frameon=False, loc="lower right")
    save(fig, OUT_DIR, "fig4_fanwin_rate.png")

    # Fig 5: Event-level flip probability ECDF
    fig, ax = plt.subplots(figsize=(9.0, 4.8))
    fp = events[flip_col].dropna().clip(0, 1).values
    fp.sort()
    ecdf = np.arange(1, len(fp)+1) / len(fp)
    cmap = pastel_cmap("#d7f3e6", "#2fa8c2", "mint_teal_ecdf")
    cols = cmap(np.linspace(0.1, 0.95, len(fp)))
    ax.plot(fp, ecdf, color=(0,0,0,0.18), lw=2.0)
    ax.scatter(fp, ecdf, c=cols, s=18, edgecolor=(1,1,1,0.6), linewidth=0.4)
    for xline, txt in [(0.1, "Low"), (0.5, "Medium"), (0.9, "High")]:
        ax.axvline(xline, color=(0,0,0,0.22), lw=1.6)
        ax.text(xline, 0.04, txt, rotation=90, va="bottom", ha="right", color=(0,0,0,0.45), fontsize=11)
    ax.set_xlim(0, 1.0)
    ax.set_ylim(0, 1.0)
    ax.set_title("Decision Uncertainty: Flip Probability (ECDF)")
    ax.set_xlabel("Flip probability (Percent vs Rank)")
    ax.set_ylabel("Empirical CDF")
    save(fig, OUT_DIR, "fig5_flip_ecdf.png")

    # Fig 6: Flip probability by observed disagreement (two ECDFs)
    fig, ax = plt.subplots(figsize=(9.0, 4.8))
    fp0 = events.loc[events[disagree_col] == 0, flip_col].dropna().clip(0, 1).values
    fp1 = events.loc[events[disagree_col] == 1, flip_col].dropna().clip(0, 1).values
    fp0.sort(); fp1.sort()
    ec0 = np.arange(1, len(fp0)+1) / len(fp0) if len(fp0) else np.array([])
    ec1 = np.arange(1, len(fp1)+1) / len(fp1) if len(fp1) else np.array([])
    ax.plot(fp0, ec0, lw=3.0, color="#7fb6ff", alpha=0.95, label=f"Observed agree (n={len(fp0)})")
    ax.plot(fp1, ec1, lw=3.0, color="#ff8b6b", alpha=0.95, label=f"Observed disagree (n={len(fp1)})")
    ax.axvline(0.5, color=(0,0,0,0.25), lw=1.6, ls="--")
    ax.set_xlim(0, 1.0)
    ax.set_ylim(0, 1.0)
    ax.set_title("Flip Probability vs Observed Rule Disagreement")
    ax.set_xlabel("Flip probability (Percent vs Rank)")
    ax.set_ylabel("Empirical CDF")
    ax.legend(frameon=False, loc="lower right")
    save(fig, OUT_DIR, "fig6_flip_by_disagree_ecdf.png")

    # Optional: Season-level coupling (Fig 7)
    fig, ax = plt.subplots(figsize=(7.2, 5.2))
    x = seasons["avg_flip_prob"].values
    y = seasons["disagree_rate"].values
    mask = (~np.isnan(x)) & (~np.isnan(y))
    cmap = pastel_cmap("#ffe8cc", "#ff8b6b", "peach")
    cols = cmap(np.linspace(0.2, 0.95, np.sum(mask)))
    ax.scatter(x[mask], y[mask], s=85, c=cols, edgecolor=(1,1,1,0.8), linewidth=0.6)
    for s, xi, yi in zip(seasons.loc[mask, "season"], x[mask], y[mask]):
        ax.text(xi + 0.005, yi + 0.002, str(int(s)), fontsize=10, color=(0,0,0,0.55))
    ax.set_xlim(0, 1.0)
    ax.set_ylim(0, max(0.05, np.nanmax(y)*1.25))
    ax.set_title("Season-level: Disagreement Rate vs Flip Uncertainty")
    ax.set_xlabel("Average flip probability (season)")
    ax.set_ylabel("Disagreement rate (season)")
    save(fig, OUT_DIR, "fig7_season_flip_vs_disagree.png")

if __name__ == "__main__":
    main()
