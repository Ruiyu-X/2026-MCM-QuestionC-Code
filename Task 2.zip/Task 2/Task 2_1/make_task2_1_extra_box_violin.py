"""
Extra figures for Task 2.1 (fan-lean evidence):
- Boxplot (paired by season) of Fan-Lean Index (FLI) for Percent vs Rank rules
- Violin plot of the same

Inputs:
- task2_1_metrics_by_event.csv
- task2_1_summary_by_season.csv

Outputs:
- task2_extra_fli_boxplot.png
- task2_extra_fli_violin.png
"""

import numpy as np
import pandas as pd
import matplotlib.pyplot as plt

EVENTS_CSV = r"task2_1_metrics_by_event.csv"
SEASONS_CSV = r"task2_1_summary_by_season.csv"

OUT_BOX = r"task2_extra_fli_boxplot.png"
OUT_VIOLIN = r"task2_extra_fli_violin.png"

def wavg(x, w):
    x = np.asarray(x, dtype=float)
    w = np.asarray(w, dtype=float)
    mask = np.isfinite(x) & np.isfinite(w)
    if mask.sum() == 0 or w[mask].sum() == 0:
        return float("nan")
    return float((x[mask]*w[mask]).sum()/w[mask].sum())

def main():
    events = pd.read_csv(EVENTS_CSV)
    seasons = pd.read_csv(SEASONS_CSV).sort_values("season").reset_index(drop=True)

    # Fan-perturbation sensitivity proxy: flip prob between rules (from event CSV)
    flip = events.get("flip_prob_percent_vs_rank", pd.Series(np.zeros(len(events)))).fillna(0.0).to_numpy()
    wFLI_percent = wavg(events["FLI_percent"], flip)
    wFLI_rank    = wavg(events["FLI_rank"], flip)

    plt.style.use("seaborn-v0_8-whitegrid")
    colors = plt.rcParams["axes.prop_cycle"].by_key().get("color", ["C0", "C1"])
    c_percent, c_rank = colors[1], colors[0]  # only re-order default palette

    fli_percent = seasons["FLI_percent"].astype(float).to_numpy()
    fli_rank    = seasons["FLI_rank"].astype(float).to_numpy()

    rng = np.random.default_rng(7)
    jit1 = 1 + rng.normal(0, 0.035, size=len(seasons))
    jit2 = 2 + rng.normal(0, 0.035, size=len(seasons))

    # -------- Boxplot (paired seasons) --------
    fig, ax = plt.subplots(figsize=(10.5, 6.2), dpi=200)
    data = [fli_percent, fli_rank]
    labels = ["Percent rule", "Rank rule"]

    bp = ax.boxplot(
        data, positions=[1, 2], widths=0.55, patch_artist=True, showfliers=False,
        medianprops=dict(linewidth=2.0),
        whiskerprops=dict(linewidth=1.5),
        capprops=dict(linewidth=1.5),
        boxprops=dict(linewidth=1.8)
    )

    for patch, col in zip(bp["boxes"], [c_percent, c_rank]):
        patch.set_facecolor(col)
        patch.set_alpha(0.22)
        patch.set_edgecolor(col)
    for i, col in enumerate([c_percent, c_rank]):
        bp["medians"][i].set_color(col)
        bp["whiskers"][2*i].set_color(col); bp["whiskers"][2*i+1].set_color(col)
        bp["caps"][2*i].set_color(col); bp["caps"][2*i+1].set_color(col)

    # paired lines + points
    for i in range(len(seasons)):
        ax.plot([1,2], [fli_percent[i], fli_rank[i]], linewidth=1.0, alpha=0.25, color="0.55", zorder=1)
    ax.scatter(jit1, fli_percent, s=28, alpha=0.75, edgecolors="white", linewidths=0.6, zorder=2)
    ax.scatter(jit2, fli_rank,    s=28, alpha=0.75, edgecolors="white", linewidths=0.6, zorder=2)

    ax.axhline(0, linestyle="--", linewidth=1.6, color="0.55")
    ax.set_xticks([1,2], labels, fontsize=14)
    ax.set_ylabel("Fan-Lean Index (FA − JA)", fontsize=16)
    ax.set_title("Fan-Lean Index by Rule (Season Level)", fontsize=22, pad=14)

    note = (f"Weight-by-sensitivity (avg over events):  wFLI_rank={wFLI_rank:.3f}, wFLI_percent={wFLI_percent:.3f}\n"
            f"(higher = closer to fan-only elimination in high-uncertainty events)")
    ax.text(0.02, 0.98, note, transform=ax.transAxes, va="top", ha="left", fontsize=11,
            bbox=dict(boxstyle="round,pad=0.35", facecolor="white", alpha=0.85, edgecolor="0.85"))

    ax.set_ylim(min(fli_percent.min(), fli_rank.min(), -0.35)-0.02, max(fli_percent.max(), fli_rank.max(), 0.35)+0.02)
    fig.tight_layout()
    fig.savefig(OUT_BOX, bbox_inches="tight")
    plt.close(fig)

    # -------- Violin --------
    fig, ax = plt.subplots(figsize=(10.5, 6.2), dpi=200)
    vp = ax.violinplot(data, positions=[1,2], widths=0.7, showmeans=False, showmedians=True, showextrema=False)

    for i, body in enumerate(vp["bodies"]):
        col = [c_percent, c_rank][i]
        body.set_facecolor(col)
        body.set_edgecolor(col)
        body.set_alpha(0.20)
        body.set_linewidth(1.6)

    vp["cmedians"].set_color("0.35")
    vp["cmedians"].set_linewidth(2.0)

    ax.scatter(jit1, fli_percent, s=28, alpha=0.70, edgecolors="white", linewidths=0.6, zorder=3)
    ax.scatter(jit2, fli_rank,    s=28, alpha=0.70, edgecolors="white", linewidths=0.6, zorder=3)

    med_percent = float(np.nanmedian(fli_percent))
    med_rank    = float(np.nanmedian(fli_rank))
    ax.text(1, med_percent, f"median={med_percent:.2f}", ha="center", va="bottom", fontsize=11, color="0.25")
    ax.text(2, med_rank,    f"median={med_rank:.2f}", ha="center", va="bottom", fontsize=11, color="0.25")

    ax.axhline(0, linestyle="--", linewidth=1.6, color="0.55")
    ax.set_xticks([1,2], labels, fontsize=14)
    ax.set_ylabel("Fan-Lean Index (FA − JA)", fontsize=16)
    ax.set_title("Fan-Lean Index Distribution by Rule (Season Level)", fontsize=22, pad=14)

    ax.set_ylim(min(fli_percent.min(), fli_rank.min(), -0.35)-0.02, max(fli_percent.max(), fli_rank.max(), 0.35)+0.02)
    fig.tight_layout()
    fig.savefig(OUT_VIOLIN, bbox_inches="tight")
    plt.close(fig)

if __name__ == "__main__":
    main()
