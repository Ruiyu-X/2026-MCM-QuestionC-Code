import pandas as pd
import numpy as np

FAN_CSV = "task1_fan_vote_estimates.csv"
DET_CSV = "task2_rule_comparison_deterministic.csv"
PROB_CSV = "task2_rule_comparison_probabilistic.csv"

USE_SCHEME = "percent"   # 主分析建议用 percent；其他 scheme 可做鲁棒性对照

def parse_set(s: str) -> set:
    if pd.isna(s) or str(s).strip() == "":
        return set()
    return set([x.strip() for x in str(s).split("|") if x.strip()])

def jaccard(a: set, b: set) -> float:
    if not a and not b:
        return 1.0
    return len(a & b) / len(a | b)

def main():
    fan = pd.read_csv(FAN_CSV)
    det = pd.read_csv(DET_CSV)
    prob = pd.read_csv(PROB_CSV)

    fan = fan[fan["scheme_assumed"].astype(str).str.lower().eq(USE_SCHEME)].copy()

    for df in (fan, det, prob):
        if "season" in df.columns:
            df["season"] = df["season"].astype(int)
        if "week" in df.columns:
            df["week"] = df["week"].astype(int)

    det = det.copy()
    det["percent_elim_set"] = det["percent_elim"].apply(parse_set)
    det["rank_elim_set"] = det["rank_elim"].apply(parse_set)
    det["actual_elim_set"] = det["actual_elim"].apply(parse_set)

    # 逐 season-week 计算指标
    rows = []
    for _, r in det.iterrows():
        season, week = int(r["season"]), int(r["week"])
        m_elim = int(r["m_elim"])

        sub = fan[(fan["season"] == season) & (fan["week"] == week)]
        if sub.empty:
            continue

        # 只保留必要列，避免缺失
        sub2 = sub[["celebrity_name", "fan_share_mean", "judge_total"]].dropna()
        if sub2.empty:
            continue

        # 粉丝淘汰基准：fan_share_mean 最低的 m_elim 人
        fan_bottom = set(sub2.sort_values("fan_share_mean", ascending=True).head(m_elim)["celebrity_name"])
        # 评委淘汰基准：judge_total 最低的 m_elim 人
        judge_bottom = set(sub2.sort_values("judge_total", ascending=True).head(m_elim)["celebrity_name"])

        E_percent = r["percent_elim_set"]
        E_rank = r["rank_elim_set"]

        # --- 指标 1&2：对齐度 ---
        FA_percent = jaccard(E_percent, fan_bottom)
        FA_rank = jaccard(E_rank, fan_bottom)
        JA_percent = jaccard(E_percent, judge_bottom)
        JA_rank = jaccard(E_rank, judge_bottom)

        # --- 指标 3：净粉丝倾向 ---
        FLI_percent = FA_percent - JA_percent
        FLI_rank = FA_rank - JA_rank

        # --- 指标 4：分歧周的粉丝友好性 ---
        disagree = int(E_percent != E_rank)

        # 用“淘汰者平均 fan_share”衡量：越小越粉丝友好（淘汰更不受粉丝欢迎的人）
        share_map = sub2.set_index("celebrity_name")["fan_share_mean"].to_dict()

        def avg_share(E: set) -> float:
            vals = [share_map.get(x, np.nan) for x in E]
            vals = [v for v in vals if pd.notna(v)]
            return float(np.mean(vals)) if vals else np.nan

        avg_fan_share_percent = avg_share(E_percent)
        avg_fan_share_rank = avg_share(E_rank)

        # percent_more_fan = 1 表示 percent 更粉丝友好；0 表示 rank 更粉丝友好
        percent_more_fan = np.nan
        if disagree and pd.notna(avg_fan_share_percent) and pd.notna(avg_fan_share_rank):
            percent_more_fan = int(avg_fan_share_percent < avg_fan_share_rank)

        rows.append({
            "season": season,
            "week": week,
            "m_elim": m_elim,
            "n_active": int(r["n_active"]),
            "disagree": disagree,

            "FA_percent": FA_percent,
            "FA_rank": FA_rank,
            "JA_percent": JA_percent,
            "JA_rank": JA_rank,
            "FLI_percent": FLI_percent,
            "FLI_rank": FLI_rank,

            "avg_fan_share_elim_percent": avg_fan_share_percent,
            "avg_fan_share_elim_rank": avg_fan_share_rank,
            "percent_more_fan_in_disagree": percent_more_fan,
        })

    metrics = pd.DataFrame(rows)

    # 合并 probabilistic 结果（用于解释“边界周/不确定性”）
    keep_cols = [
        "season", "week",
        "flip_prob_percent_vs_rank",
        "p_match_obs_percent", "p_match_obs_rank"
    ]
    prob_small = prob[keep_cols].drop_duplicates()
    metrics = metrics.merge(prob_small, on=["season", "week"], how="left")

    # --- 按 season 汇总 ---
    summary = metrics.groupby("season").agg(
        n_events=("week", "count"),
        disagree_rate=("disagree", "mean"),
        FA_percent=("FA_percent", "mean"),
        FA_rank=("FA_rank", "mean"),
        JA_percent=("JA_percent", "mean"),
        JA_rank=("JA_rank", "mean"),
        FLI_percent=("FLI_percent", "mean"),
        FLI_rank=("FLI_rank", "mean"),
        # 在分歧周里 percent 更粉丝友好的比例（越大说明 percent 更靠近粉丝淘汰）
        percent_more_fan_rate_in_disagree=("percent_more_fan_in_disagree", "mean"),
        avg_flip_prob=("flip_prob_percent_vs_rank", "mean"),
    ).reset_index()

    metrics.to_csv("task2_1_metrics_by_event.csv", index=False)
    summary.to_csv("task2_1_summary_by_season.csv", index=False)

    print("Saved:")
    print(" - task2_1_metrics_by_event.csv")
    print(" - task2_1_summary_by_season.csv")

    overall = metrics.agg({
        "disagree": "mean",
        "FA_percent": "mean", "FA_rank": "mean",
        "JA_percent": "mean", "JA_rank": "mean",
        "FLI_percent": "mean", "FLI_rank": "mean"
    })
    print("\nOverall means:")
    print(overall)

if __name__ == "__main__":
    main()