"""
Task 2 (Q2) – Ensemble/Union mode
=====================================
What this script does
---------------------
(1) Quantifies "controversy" for each celebrity in each season using a *multi-factor* index:
    - Judge–Fan disagreement (rank divergence across weeks)
    - Fan vs Judge direction (fan_adv)
    - "Success despite low judge support" (success_low_judge = success * judge_bad)
    - A small "protection" term from the rule-based simulated elimination (protect)

(2) Runs three elimination rules for every season:
    - percent: 0.5*judge_percent + 0.5*fan_share_mean
    - rank:    rank(judge_total) + rank(fan_share_mean)
    - bottom2save: rank-rule bottom-2, then judges eliminate the lower judge_total of the bottom-2

(3) Ensemble/Union selection (per season):
    - Take Top-3 controversial under each rule (percent / rank / bottom2save)
    - UNION the candidates (size <= 9)
    - Compute an ensemble score = mean z-score across the three rule scores
    - Report Final Top-3 (ensemble) + outcome shifts (elim_week differences)

Inputs
------
- 2026_MCM_Problem_C_Data.csv
- task1_fan_vote_estimates.csv

Run:
  python task2_2_ensemble_union.py --raw 2026_MCM_Problem_C_Data.csv --fan task1_fan_vote_estimates.csv --out_dir task2_2_ensemble_union

Outputs (in --out_dir)
----------------------
CSV:
- task2_2_scores_by_rule.csv
- task2_2_top3_each_rule.csv
- task2_2_union_candidates.csv
- task2_2_final_top3_ensemble.csv

Figures (in out_dir/figs):
- fig_q2_union_pool_size_v2.png
- fig_q2_rule_impact_violin_v2.png
- fig_q2_scatter_season11_Bristol_Palin.png
- fig_q2_scatter_season27_Bobby_Bones.png
"""

from __future__ import annotations
import argparse
from pathlib import Path
import numpy as np
import pandas as pd
import matplotlib.pyplot as plt
import matplotlib as mpl
from matplotlib.colors import LinearSegmentedColormap


def pastel_cmap(hex1: str, hex2: str, name: str = "cmap"):
    return LinearSegmentedColormap.from_list(name, [hex1, hex2])


def rank_norm(values, higher_better=True):
    """Return normalized rank in [0,1] where 0=best, 1=worst."""
    x = np.asarray(values, dtype=float)
    if np.all(~np.isfinite(x)):
        return np.full_like(x, np.nan, dtype=float)
    if not np.all(np.isfinite(x)):
        fill = np.nanmin(x) if higher_better else np.nanmax(x)
        x = np.where(np.isfinite(x), x, fill)

    order = (-x).argsort() if higher_better else (x).argsort()
    ranks = np.empty_like(order, dtype=float)
    ranks[order] = np.arange(1, len(x) + 1)
    if len(x) == 1:
        return np.zeros_like(x, dtype=float)
    return (ranks - 1) / (len(x) - 1)


def zscore(x):
    x = np.asarray(x, dtype=float)
    mu = np.nanmean(x)
    sd = np.nanstd(x)
    if (not np.isfinite(sd)) or sd == 0:
        return np.zeros_like(x, dtype=float)
    return (x - mu) / sd


def simulate_elimination(season_fan: pd.DataFrame, rule: str):
    """
    rule in {"percent","rank","bottom2save"}
    Return: elim_week dict (celebrity -> elimination week), winner set is those with None.
    """
    df = season_fan.copy()
    df = df[np.isfinite(df["judge_total"])].copy()
    maxw = int(df["week"].max())

    celebs = df["celebrity_name"].unique().tolist()
    active = set(celebs)
    elim = {c: None for c in celebs}

    for w in range(1, maxw + 1):
        wdf = df[df["week"] == w].copy()
        wdf = wdf[wdf["celebrity_name"].isin(active)]
        if len(wdf) <= 1:
            break

        # normalize fan share over active set
        s = np.nansum(wdf["fan_share_mean"].to_numpy(float))
        if s > 0:
            wdf["fan_share_mean"] = wdf["fan_share_mean"] / s

        jt = wdf["judge_total"].to_numpy(float)
        jp = wdf["judge_percent"].to_numpy(float)
        fs = wdf["fan_share_mean"].to_numpy(float)

        if rule == "percent":
            score = 0.5 * jp + 0.5 * fs
            elim_name = wdf.iloc[int(np.nanargmin(score))]["celebrity_name"]
        else:
            rj = rank_norm(jt, higher_better=True)
            rf = rank_norm(fs, higher_better=True)
            comb = rj + rf  # lower is better

            if rule == "rank":
                elim_name = wdf.iloc[int(np.nanargmax(comb))]["celebrity_name"]
            else:
                worst_idx = np.argsort(-comb)[:2]
                bottom = wdf.iloc[worst_idx].copy()
                # judges eliminate the lower judge_total among bottom-2
                jts = bottom["judge_total"].to_numpy(float)
                elim_name = bottom.iloc[int(np.nanargmin(jts))]["celebrity_name"]

        active.remove(elim_name)
        elim[elim_name] = w
        if len(active) == 1:
            break

    return elim


def base_weekly_metrics(season_fan: pd.DataFrame):
    """
    Per celebrity:
    - divergence: mean |rank_judge - rank_fan| across weeks
    - fan_adv:    mean (rank_fan - rank_judge) across weeks (positive means fan likes more)
    - judge_bad:  mean rank_judge (0 best -> 1 worst)
    """
    celebs = season_fan["celebrity_name"].unique().tolist()
    rows = []

    for c in celebs:
        disc, adv, jbad = [], [], []
        for _w, wdf in season_fan.groupby("week"):
            wdf = wdf[np.isfinite(wdf["judge_total"])].copy()
            if len(wdf) <= 1 or c not in wdf["celebrity_name"].values:
                continue

            rj = rank_norm(wdf["judge_total"].to_numpy(float), True)
            rf = rank_norm(wdf["fan_share_mean"].to_numpy(float), True)
            idx = wdf.index.get_loc(wdf[wdf["celebrity_name"] == c].index[0])

            disc.append(abs(rj[idx] - rf[idx]))
            adv.append(rf[idx] - rj[idx])
            jbad.append(rj[idx])

        rows.append((
            c,
            float(np.nanmean(disc)),
            float(np.nanmean(adv)),
            float(np.nanmean(jbad)),
        ))

    return pd.DataFrame(rows, columns=["celebrity_name", "divergence", "fan_adv", "judge_bad"])


def season_success(raw_season: pd.DataFrame):
    """Success in [0,1]: winner=1, early exit~0, based on placement rank."""
    N = len(raw_season)
    out = {}
    for _, r in raw_season.iterrows():
        p = float(r["placement"])
        out[r["celebrity_name"]] = (N - p) / (N - 1) if N > 1 else 1.0
    return out


def compute_season_scores(season: int, fan: pd.DataFrame, raw: pd.DataFrame):
    sfan = fan[fan["season"] == season].copy()
    sraw = raw[raw["season"] == season].copy()
    if len(sfan) == 0:
        return None

    base = base_weekly_metrics(sfan)
    suc = season_success(sraw)
    base["success"] = base["celebrity_name"].map(suc)

    # key term: controversial if they go far despite judges rating them low
    base["success_low_judge"] = base["success"] * base["judge_bad"]

    base["z_div"] = zscore(base["divergence"])
    base["z_adv"] = zscore(base["fan_adv"])
    base["z_slj"] = zscore(base["success_low_judge"])

    maxw = int(sfan["week"].max())
    rows = []

    for rule in ["percent", "rank", "bottom2save"]:
        elim = simulate_elimination(sfan, rule)
        tmp = base.copy()
        tmp["season"] = season
        tmp["rule"] = rule
        tmp["elim_week_rule"] = tmp["celebrity_name"].map(lambda c: elim.get(c) if elim.get(c) is not None else (maxw + 1))
        tmp["protect"] = tmp["elim_week_rule"] / (maxw + 1)
        tmp["z_protect"] = zscore(tmp["protect"])

        # multi-factor controversy score (within-season standardized)
        tmp["controversy_score_rule"] = (
            0.35 * tmp["z_div"] +
            0.15 * tmp["z_adv"] +
            0.45 * tmp["z_slj"] +
            0.05 * tmp["z_protect"]
        )

        rows.append(tmp[[
            "season", "rule", "celebrity_name",
            "divergence", "fan_adv", "judge_bad",
            "success", "success_low_judge",
            "elim_week_rule", "controversy_score_rule"
        ]])

    return pd.concat(rows, ignore_index=True)


def beautify(ax):
    ax.grid(True, axis="y", alpha=0.25)
    ax.set_axisbelow(True)
    ax.spines["top"].set_visible(False)
    ax.spines["right"].set_visible(False)
    ax.spines["left"].set_alpha(0.35)
    ax.spines["bottom"].set_alpha(0.35)


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--raw", type=str, default="2026_MCM_Problem_C_Data.csv")
    ap.add_argument("--fan", type=str, default="task1_fan_vote_estimates.csv")
    ap.add_argument("--out_dir", type=str, default="task2_2_ensemble_union")
    args = ap.parse_args()

    raw = pd.read_csv(args.raw)
    fan = pd.read_csv(args.fan)

    out_dir = Path(args.out_dir)
    fig_dir = out_dir / "figs"
    out_dir.mkdir(parents=True, exist_ok=True)
    fig_dir.mkdir(parents=True, exist_ok=True)

    all_scores = []
    top3_rows = []
    union_rows = []
    final_rows = []

    for season in sorted(raw["season"].unique()):
        sc = compute_season_scores(int(season), fan, raw)
        if sc is None:
            continue
        all_scores.append(sc)

        # Top-3 each rule
        top_by = {}
        for rule in ["percent", "rank", "bottom2save"]:
            g = sc[sc["rule"] == rule].sort_values("controversy_score_rule", ascending=False).head(3).copy()
            top_by[rule] = g["celebrity_name"].tolist()
            g["topk_rule"] = rule
            top3_rows.append(g)

        # union candidates
        union_set = set(sum(top_by.values(), []))
        maxw = int(fan[fan["season"] == season]["week"].max())
        sraw = raw[raw["season"] == season].set_index("celebrity_name")

        ens_records = []
        for c in union_set:
            sub = sc[sc["celebrity_name"] == c]
            zvals = []
            for rule in ["percent", "rank", "bottom2save"]:
                g = sc[sc["rule"] == rule]
                mu = g["controversy_score_rule"].mean()
                sd = g["controversy_score_rule"].std(ddof=0)
                val = float(sub[sub["rule"] == rule]["controversy_score_rule"].iloc[0])
                if sd > 0:
                    zvals.append((val - mu) / sd)

            ensemble_z = float(np.mean(zvals)) if zvals else np.nan
            ew = {r: int(sub[sub["rule"] == r]["elim_week_rule"].iloc[0]) for r in ["percent", "rank", "bottom2save"]}

            union_rows.append({
                "season": int(season),
                "celebrity_name": c,
                "ensemble_zscore": ensemble_z,
                "in_top3_percent": int(c in top_by["percent"]),
                "in_top3_rank": int(c in top_by["rank"]),
                "in_top3_bottom2save": int(c in top_by["bottom2save"]),
                "elim_week_percent": ew["percent"],
                "elim_week_rank": ew["rank"],
                "elim_week_bottom2save": ew["bottom2save"],
            })

            ens_records.append((c, ensemble_z, ew))

        ens_df = pd.DataFrame([
            {"celebrity_name": c, "ensemble_zscore": z,
             "elim_week_percent": ew["percent"], "elim_week_rank": ew["rank"], "elim_week_bottom2save": ew["bottom2save"]}
            for c, z, ew in ens_records
        ]).sort_values("ensemble_zscore", ascending=False)

        top3_ens = ens_df.head(3).copy()
        top3_ens["season"] = int(season)
        top3_ens["ensemble_rank"] = np.arange(1, len(top3_ens) + 1)
        top3_ens["placement_actual"] = top3_ens["celebrity_name"].map(lambda x: float(sraw.loc[x, "placement"]))
        top3_ens["results_actual"] = top3_ens["celebrity_name"].map(lambda x: str(sraw.loc[x, "results"]))
        top3_ens["delta_rank_minus_percent"] = top3_ens["elim_week_rank"] - top3_ens["elim_week_percent"]
        top3_ens["delta_b2s_minus_percent"] = top3_ens["elim_week_bottom2save"] - top3_ens["elim_week_percent"]
        final_rows.append(top3_ens)

    scores_all = pd.concat(all_scores, ignore_index=True)
    top3_by_rule = pd.concat(top3_rows, ignore_index=True)
    union_df = pd.DataFrame(union_rows)
    final_df = pd.concat(final_rows, ignore_index=True)

    # Save CSV
    scores_all.to_csv(out_dir / "task2_2_scores_by_rule.csv", index=False)
    top3_by_rule.to_csv(out_dir / "task2_2_top3_each_rule.csv", index=False)
    union_df.to_csv(out_dir / "task2_2_union_candidates.csv", index=False)
    final_df.to_csv(out_dir / "task2_2_final_top3_ensemble.csv", index=False)

    # ---------- Figures ----------
    mpl.rcParams.update({
        "figure.facecolor": "white",
        "axes.facecolor": "white",
        "savefig.facecolor": "white",
        "axes.titlesize": 18,
        "axes.labelsize": 13,
        "xtick.labelsize": 11,
        "ytick.labelsize": 11
    })

    # Fig 1: union pool size
    u = union_df.groupby("season").agg(union_size=("celebrity_name", "nunique")).reset_index().sort_values("season")
    fig, ax = plt.subplots(figsize=(12, 4.8), dpi=200)
    cmap = pastel_cmap("#d7f3ff", "#ffe6d6", "blue_peach")
    cols = cmap(np.linspace(0.2, 0.95, len(u)))
    ax.bar(u["season"], u["union_size"], color=cols, edgecolor=(0, 0, 0, 0.06), linewidth=0.8)
    ax.set_title("Controversial Candidate Pool (Union of Top-3 per Rule)")
    ax.set_xlabel("Season")
    ax.set_ylabel("Union size (<= 9)")
    ax.set_ylim(0, 9.5)
    beautify(ax)
    fig.tight_layout()
    fig.savefig(fig_dir / "fig_q2_union_pool_size_v2.png", bbox_inches="tight")
    plt.close(fig)

    # Fig 2: violin of outcome shifts (for final top-3)
    d = final_df.copy()
    fig, ax = plt.subplots(figsize=(8.5, 5.8), dpi=220)
    data = [d["delta_rank_minus_percent"].to_numpy(float), d["delta_b2s_minus_percent"].to_numpy(float)]
    vp = ax.violinplot(data, positions=[1, 2], widths=0.75, showmeans=False, showmedians=True, showextrema=False)

    cols = [
        pastel_cmap("#ffe6d6", "#ffb6c8", "peach_pink")(0.6),
        pastel_cmap("#d6f5ff", "#86d9c6", "sky_mint")(0.65),
    ]
    for i, body in enumerate(vp["bodies"]):
        body.set_facecolor(cols[i])
        body.set_edgecolor(cols[i])
        body.set_alpha(0.35)
        body.set_linewidth(1.6)
    vp["cmedians"].set_color("0.35")
    vp["cmedians"].set_linewidth(2.0)

    rng = np.random.default_rng(3)
    for i, arr in enumerate(data, start=1):
        jit = i + rng.normal(0, 0.04, size=len(arr))
        ax.scatter(jit, arr, s=24, alpha=0.5, edgecolors="white", linewidths=0.5)

    ax.axhline(0, ls="--", lw=1.6, color="0.55")
    ax.set_xticks([1, 2], ["Rank − Percent", "Bottom2Save − Percent"])
    ax.set_ylabel("Δ elimination week (positive = later / safer)")
    ax.set_title("How Alternative Rules Shift Outcomes (Final Top-3 Controversial)")
    ax.spines["top"].set_visible(False)
    ax.spines["right"].set_visible(False)
    fig.tight_layout()
    fig.savefig(fig_dir / "fig_q2_rule_impact_violin_v2.png", bbox_inches="tight")
    plt.close(fig)

    # Fig 3/4: scatter examples for Bristol Palin & Bobby Bones (if present)
    for s_sel, name in [(11, "Bristol Palin"), (27, "Bobby Bones")]:
        sf = fan[fan["season"] == s_sel].copy()
        if len(sf) == 0:
            continue
        w = int(sf["week"].max())
        wdf = sf[sf["week"] == w].copy()
        wdf = wdf[np.isfinite(wdf["judge_total"]) & np.isfinite(wdf["fan_share_mean"])].copy()
        if len(wdf) == 0:
            continue
        wdf["fan_share_mean"] = wdf["fan_share_mean"] / wdf["fan_share_mean"].sum()

        wdf["judge_rank"] = rank_norm(wdf["judge_total"].to_numpy(float), True)
        wdf["fan_rank"] = rank_norm(wdf["fan_share_mean"].to_numpy(float), True)

        hi = wdf[wdf["celebrity_name"] == name]

        fig, ax = plt.subplots(figsize=(7.2, 6.2), dpi=220)
        ax.scatter(wdf["judge_rank"], wdf["fan_rank"], s=65, alpha=0.70, edgecolors="white", linewidths=0.6)
        if len(hi):
            ax.scatter(hi["judge_rank"], hi["fan_rank"], s=220, alpha=0.95, edgecolors="white", linewidths=1.0)
            ax.text(float(hi["judge_rank"].iloc[0]) + 0.02, float(hi["fan_rank"].iloc[0]) + 0.02, name, fontsize=11, alpha=0.85)

        ax.plot([0, 1], [0, 1], ls="--", lw=1.6, color=(0, 0, 0, 0.35))
        ax.set_title(f"Season {s_sel}: Fan vs Judge Rank (highlight: {name})")
        ax.set_xlabel("Judge rank (0=best, 1=worst)")
        ax.set_ylabel("Fan rank (0=best, 1=worst)")
        ax.set_xlim(-0.02, 1.02)
        ax.set_ylim(-0.02, 1.02)
        ax.grid(True, alpha=0.25)
        ax.spines["top"].set_visible(False)
        ax.spines["right"].set_visible(False)
        fig.tight_layout()
        fig.savefig(fig_dir / f"fig_q2_scatter_season{s_sel}_{name.replace(' ', '_')}.png", bbox_inches="tight")
        plt.close(fig)

    print(f"[OK] Wrote CSV + figures to: {out_dir.resolve()}")


if __name__ == "__main__":
    main()
