# task3_models.py
import re
import numpy as np
import pandas as pd
import statsmodels.api as sm
import statsmodels.formula.api as smf
import matplotlib.pyplot as plt

RAW_PATH = "2026_MCM_Problem_C_Data.csv"
FAN_EST_PATH = "task1_fan_vote_estimates.csv"
OUT_DIR = "task3_out"

def parse_exit_week(res, max_week):
    if isinstance(res, str):
        m = re.search(r"Eliminated Week (\d+)", res)
        if m:
            return int(m.group(1)), "eliminated"
        m = re.search(r"Withdrew Week (\d+)", res)
        if m:
            return int(m.group(1)), "withdrew"
        return max_week + 1, "finalist"
    return max_week + 1, "finalist"

def zscore(s):
    return (s - s.mean()) / (s.std(ddof=0) + 1e-12)

def ensure_dir(path):
    import os
    os.makedirs(path, exist_ok=True)

def extract_group_effects(params, prefix):
    # prefix like "C(industry)"
    out = {}
    for k, v in params.items():
        if k.startswith(prefix):
            m = re.search(r"\[T\.(.*)\]", k)
            if m:
                out[m.group(1)] = v
    return out

def main():
    ensure_dir(OUT_DIR)

    raw = pd.read_csv(RAW_PATH)
    fan = pd.read_csv(FAN_EST_PATH)

    # ---- infer max week from raw score columns (week{w}_judge{j}_score)
    score_cols = [c for c in raw.columns if re.match(r"week\d+_judge\d+_score", c)]
    weeks = sorted({int(re.findall(r"week(\d+)_", c)[0]) for c in score_cols})
    max_week = max(weeks)

    # ---- parse exit week
    tmp = raw["results"].apply(lambda x: parse_exit_week(x, max_week))
    raw["exit_week"] = tmp.apply(lambda t: t[0])
    raw["exit_type"] = tmp.apply(lambda t: t[1])

    # ---- fan ensemble across schemes (precision-weighted)
    fan = fan.copy()
    fan["w"] = 1.0 / (fan["fan_share_sd"] ** 2 + 1e-9)
    fan_ens = (
        fan.groupby(["season", "week", "celebrity_name"], as_index=False)
        .apply(lambda g: pd.Series({
            "fan_share": np.average(g["fan_share_mean"], weights=g["w"]),
            "fan_sd": np.sqrt(1.0 / g["w"].sum()),
            "industry": g["industry"].iloc[0],
            "age_from_task1": g["age"].iloc[0],
        }))
        .reset_index(drop=True)
    )

    # ---- build week-level panel
    rows = []
    for _, r in raw.iterrows():
        season = int(r["season"])
        celeb = r["celebrity_name"]
        exit_week = int(r["exit_week"])
        # include weeks up to eliminated week (inclusive) or max_week
        last = min(exit_week, max_week)
        for w in range(1, last + 1):
            eliminated = int(w == exit_week and r["exit_type"] == "eliminated")

            js = []
            for j in range(1, 5):
                col = f"week{w}_judge{j}_score"
                if col in raw.columns and pd.notna(r[col]):
                    js.append(r[col])
            judge_mean = float(np.mean(js)) if len(js) else np.nan

            rows.append({
                "season": season,
                "week": w,
                "celebrity_name": celeb,
                "ballroom_partner": r.get("ballroom_partner", np.nan),
                "homestate": r.get("celebrity_homestate", np.nan),
                "homecountry_region": r.get("celebrity_homecountry/region", np.nan),
                "age": r.get("celebrity_age_during_season", np.nan),
                "judge_mean": judge_mean,
                "eliminated_this_week": eliminated,
            })

    panel = pd.DataFrame(rows)

    # merge fan ensemble
    panel = panel.merge(
        fan_ens[["season", "week", "celebrity_name", "fan_share", "fan_sd", "industry"]],
        on=["season", "week", "celebrity_name"],
        how="left"
    )

    # pro dancer performance proxy: partner's global mean judge score
    partner_skill = (
        panel.groupby("ballroom_partner", as_index=False)["judge_mean"]
        .mean()
        .rename(columns={"judge_mean": "partner_skill"})
    )
    panel = panel.merge(partner_skill, on="ballroom_partner", how="left")

    # clean + standardize
    df = panel.dropna(subset=[
        "judge_mean", "fan_share", "fan_sd",
        "age", "industry", "homecountry_region", "partner_skill"
    ]).copy()

    df["judge_z"] = zscore(df["judge_mean"])
    df["fan_z"]   = zscore(df["fan_share"])
    df["age_z"]   = zscore(df["age"])
    df["pro_z"]   = zscore(df["partner_skill"])

    df["industry"] = df["industry"].astype(str)
    df["homecountry_region"] = df["homecountry_region"].astype(str)

    # -------------------------
    # Model 1: elimination hazard (logit)
    # -------------------------
    f1 = "eliminated_this_week ~ judge_z + fan_z + age_z + pro_z + C(industry) + C(homecountry_region) + C(season) + C(week)"
    m1 = smf.glm(f1, data=df, family=sm.families.Binomial()).fit()

    # -------------------------
    # Model 2: judge preference (OLS)
    # -------------------------
    f2 = "judge_z ~ age_z + pro_z + C(industry) + C(homecountry_region) + C(season) + C(week)"
    m2 = smf.ols(f2, data=df).fit(cov_type="cluster", cov_kwds={"groups": df["celebrity_name"]})

    # -------------------------
    # Model 3: fan preference (WLS)  weight = 1 / fan_sd^2
    # -------------------------
    df["w_fan"] = 1.0 / (df["fan_sd"] ** 2 + 1e-9)
    f3 = "fan_z ~ age_z + pro_z + C(industry) + C(homecountry_region) + C(season) + C(week)"
    m3 = smf.wls(f3, data=df, weights=df["w_fan"]).fit(cov_type="cluster", cov_kwds={"groups": df["celebrity_name"]})

    # ---- save summaries
    with open(f"{OUT_DIR}/task3_model_summaries.txt", "w", encoding="utf-8") as f:
        f.write("=== Model 1: Elimination hazard (GLM Binomial) ===\n")
        f.write(m1.summary().as_text())
        f.write("\n\n=== Model 2: Judge preference (OLS, clustered SE) ===\n")
        f.write(m2.summary().as_text())
        f.write("\n\n=== Model 3: Fan preference (WLS, clustered SE) ===\n")
        f.write(m3.summary().as_text())

    # ---- core effects table (standardized)
    core = pd.DataFrame({
        "feature": ["judge_z", "fan_z", "age_z", "pro_z"],
        "elim_beta": [m1.params.get("judge_z", np.nan), m1.params.get("fan_z", np.nan),
                     m1.params.get("age_z", np.nan), m1.params.get("pro_z", np.nan)],
        "elim_p":    [m1.pvalues.get("judge_z", np.nan), m1.pvalues.get("fan_z", np.nan),
                     m1.pvalues.get("age_z", np.nan), m1.pvalues.get("pro_z", np.nan)],
        "judge_beta": [np.nan, np.nan, m2.params.get("age_z", np.nan), m2.params.get("pro_z", np.nan)],
        "judge_p":    [np.nan, np.nan, m2.pvalues.get("age_z", np.nan), m2.pvalues.get("pro_z", np.nan)],
        "fan_beta":   [np.nan, np.nan, m3.params.get("age_z", np.nan), m3.params.get("pro_z", np.nan)],
        "fan_p":      [np.nan, np.nan, m3.pvalues.get("age_z", np.nan), m3.pvalues.get("pro_z", np.nan)],
    })
    core.to_csv(f"{OUT_DIR}/task3_core_effects.csv", index=False)

    # ---- sign agreement on categorical blocks
    judge_ind = extract_group_effects(m2.params, "C(industry)")
    fan_ind   = extract_group_effects(m3.params, "C(industry)")
    common_ind = sorted(set(judge_ind).intersection(fan_ind))

    ind_rows = []
    for lvl in common_ind:
        j = judge_ind[lvl]
        ff = fan_ind[lvl]
        ind_rows.append({
            "industry_level": lvl,
            "judge_coef": j,
            "fan_coef": ff,
            "sign_agree": int(np.sign(j) == np.sign(ff)),
            "abs_gap": abs(j - ff),
        })
    ind_df = pd.DataFrame(ind_rows).sort_values("abs_gap", ascending=False)
    ind_df.to_csv(f"{OUT_DIR}/task3_industry_coef_compare.csv", index=False)

    # ---- figure: industry judge vs fan coefficient scatter
    plt.figure(figsize=(8, 7))
    plt.axhline(0, linestyle="--", linewidth=1)
    plt.axvline(0, linestyle="--", linewidth=1)
    plt.plot([-1, 1], [-1, 1], linestyle=":", linewidth=1)  # y=x
    plt.scatter(ind_df["judge_coef"], ind_df["fan_coef"], alpha=0.8)
    plt.xlabel("Judge model coefficient (industry effects)")
    plt.ylabel("Fan model coefficient (industry effects)")
    plt.title("Industry Effects: Judge vs Fan (sign consistency & gaps)")

    # annotate top-5 disagreements
    for _, rr in ind_df.head(5).iterrows():
        plt.text(rr["judge_coef"], rr["fan_coef"], rr["industry_level"], fontsize=9)

    plt.tight_layout()
    plt.savefig(f"{OUT_DIR}/fig_task3_industry_judge_vs_fan.png", dpi=220)
    plt.close()

    # ---- figure: core betas (age/pro) comparison
    plt.figure(figsize=(7, 5))
    labels = ["age_z", "pro_z"]
    x = np.arange(len(labels))
    plt.axhline(0, linestyle="--", linewidth=1)
    plt.plot(x - 0.1, [m2.params.get("age_z", 0), m2.params.get("pro_z", 0)], marker="o", linewidth=2, label="Judge model")
    plt.plot(x + 0.1, [m3.params.get("age_z", 0), m3.params.get("pro_z", 0)], marker="o", linewidth=2, label="Fan model")
    plt.xticks(x, labels)
    plt.ylabel("Standardized coefficient")
    plt.title("Core Feature Effects on Judge vs Fan Preference")
    plt.legend()
    plt.tight_layout()
    plt.savefig(f"{OUT_DIR}/fig_task3_core_coef_compare.png", dpi=220)
    plt.close()

    # ---- report sign agreement rates
    sign_agree_rate_ind = ind_df["sign_agree"].mean() if len(ind_df) else np.nan
    corr_ind = ind_df[["judge_coef", "fan_coef"]].corr().iloc[0, 1] if len(ind_df) >= 2 else np.nan
    report = pd.DataFrame([{
        "industry_sign_agreement_rate": sign_agree_rate_ind,
        "industry_coef_corr": corr_ind,
        "n_industry_levels": len(ind_df),
    }])
    report.to_csv(f"{OUT_DIR}/task3_sign_agreement_report.csv", index=False)

    print("Done. Outputs saved to:", OUT_DIR)

if __name__ == "__main__":
    main()